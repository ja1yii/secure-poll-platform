/* ==========================================
   SecurePoll - script.js
   Educational Voting Prototype
   ========================================== */

"use strict";

/* -----------------------------
   Demo user
----------------------------- */

const DEMO_USER = {
  voterId: "VOT-2026-0341",
  password: "Vote@123",
  name: "Asha Verma",
  phone: "+91 ••••••4821"
};

/* -----------------------------
   Demo candidates
----------------------------- */

const CANDIDATES = [
  {
    id: "c1",
    name: "Meera Kulkarni",
    party: "Unity Party"
  },
  {
    id: "c2",
    name: "Rohan Deshpande",
    party: "Progress Alliance"
  },
  {
    id: "c3",
    name: "Ananya Patil",
    party: "People's Front"
  },
  {
    id: "c4",
    name: "Vikram Joshi",
    party: "Civic Reform Party"
  }
];

/* -----------------------------
   Demo vote counts
----------------------------- */

const results = {
  c1: 128,
  c2: 96,
  c3: 74,
  c4: 52
};

/* -----------------------------
   Application state
----------------------------- */

let currentStep = 1;
let currentVoter = null;
let currentCandidate = null;

let generatedOTP = "";
let otpTimer = null;
let otpSeconds = 60;

let cameraStream = null;
let hasFaceVerification = false;

/* -----------------------------
   DOM helper
----------------------------- */

const $ = (selector) => document.querySelector(selector);

const $$ = (selector) => document.querySelectorAll(selector);

/* -----------------------------
   Step navigation
----------------------------- */

function goToStep(step) {
  currentStep = step;

  $$(".stage-view").forEach((view) => {
    view.classList.remove("is-active");
  });

  const activeView = document.querySelector(
    `.stage-view[data-view="${step}"]`
  );

  if (activeView) {
    activeView.classList.add("is-active");
  }

  $$(".demo-progress .dot").forEach((dot) => {
    dot.classList.remove("is-active");

    if (Number(dot.dataset.step) === step) {
      dot.classList.add("is-active");
    }
  });

  const demoSection = $("#demo");

  if (demoSection) {
    demoSection.scrollIntoView({
      behavior: "smooth",
      block: "start"
    });
  }
}

/* -----------------------------
   Login
----------------------------- */

function login() {
  const voterId = $("#login-voter-id").value.trim();
  const password = $("#login-password").value;

  const error = $("#login-error");

  error.hidden = true;
  error.textContent = "";

  if (!voterId || !password) {
    error.textContent = "Please enter voter ID and password.";
    error.hidden = false;
    return;
  }

  if (
    voterId.toUpperCase() !== DEMO_USER.voterId ||
    password !== DEMO_USER.password
  ) {
    error.textContent =
      "Invalid login. Use the demo credentials shown below.";
    error.hidden = false;
    return;
  }

  currentVoter = DEMO_USER;
  hasFaceVerification = false;
  currentCandidate = null;

  $("#face-status").textContent =
    "Login successful. Complete face verification to continue.";

  goToStep(2);
}

/* -----------------------------
   Forgot password
----------------------------- */

function forgotPassword() {
  alert(
    "Educational demo:\n\n" +
    "Password recovery would normally use a secure backend, " +
    "email/SMS verification and a reset-token system."
  );
}

/* -----------------------------
   Camera
----------------------------- */

async function turnOnCamera() {
  const video = $("#camera-feed");
  const placeholder = $("#camera-placeholder");
  const cameraButton = $("#btn-camera");
  const verifyButton = $("#btn-verify-face");

  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    placeholder.textContent =
      "Camera is not available. You can use demo verification.";
    verifyButton.disabled = false;

    return;
  }

  try {
    cameraStream = await navigator.mediaDevices.getUserMedia({
      video: {
        facingMode: "user"
      },
      audio: false
    });

    video.srcObject = cameraStream;

    placeholder.style.display = "none";
    cameraButton.textContent = "Camera On";
    verifyButton.disabled = false;

    $("#face-status").textContent =
      "Camera is active. Click Verify Face to continue.";
  } catch (error) {
    console.warn("Camera permission:", error);

    placeholder.textContent =
      "Camera permission was not granted. Demo verification is available.";

    verifyButton.disabled = false;

    $("#face-status").textContent =
      "Camera unavailable. Click Verify Face for demo verification.";
  }
}

/* -----------------------------
   Face verification
----------------------------- */

function verifyFace() {
  const status = $("#face-status");
  const button = $("#btn-verify-face");

  button.disabled = true;
  button.textContent = "Verifying...";

  status.textContent = "Analyzing face data...";

  setTimeout(() => {
    hasFaceVerification = true;

    button.textContent = "Face Verified ✓";

    status.textContent =
      "Face verification successful. Sending OTP...";

    setTimeout(() => {
      sendOTP();
      goToStep(3);
    }, 700);
  }, 1200);
}

/* -----------------------------
   OTP generation
----------------------------- */

function generateOTP() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

/* -----------------------------
   Send OTP
----------------------------- */

function sendOTP() {
  clearInterval(otpTimer);

  generatedOTP = generateOTP();
  otpSeconds = 60;

  $("#demo-otp-code").textContent = generatedOTP;
  $("#otp-timer").textContent = otpSeconds;

  $("#otp-sent-to").textContent =
    `A 6-digit OTP was generated for ${currentVoter?.phone || "the demo voter"}.`;

  $("#otp-resend-status").textContent = "";

  $("#otp-error").hidden = true;

  $$(".otp-box").forEach((input) => {
    input.value = "";
  });

  if ($(".otp-box")) {
    $(".otp-box").focus();
  }

  updateResendButton();

  otpTimer = setInterval(() => {
    otpSeconds--;

    $("#otp-timer").textContent = otpSeconds;

    updateResendButton();

    if (otpSeconds <= 0) {
      clearInterval(otpTimer);

      $("#otp-timer").textContent = "0";

      $("#otp-error").textContent =
        "OTP expired. Please click Resend OTP.";

      $("#otp-error").hidden = false;
    }
  }, 1000);
}

/* -----------------------------
   Resend OTP
----------------------------- */

function resendOTP() {
  if (otpSeconds > 0) {
    $("#otp-resend-status").textContent =
      `Please wait ${otpSeconds} seconds before requesting another OTP.`;
    return;
  }

  sendOTP();

  $("#otp-resend-status").textContent =
    "A new OTP has been generated.";

  $("#otp-error").hidden = true;
}

/* -----------------------------
   Resend button state
----------------------------- */

function updateResendButton() {
  const button = $("#btn-resend-otp");

  if (!button) return;

  if (otpSeconds > 0) {
    button.disabled = true;
    button.textContent = `Resend OTP (${otpSeconds}s)`;
  } else {
    button.disabled = false;
    button.textContent = "Resend OTP";
  }
}

/* -----------------------------
   OTP verification
----------------------------- */

function verifyOTP() {
  const otp = Array.from($$(".otp-box"))
    .map((input) => input.value.trim())
    .join("");

  const error = $("#otp-error");

  error.hidden = true;
  error.textContent = "";

  if (otp.length !== 6) {
    error.textContent = "Please enter the complete 6-digit OTP.";
    error.hidden = false;
    return;
  }

  if (otpSeconds <= 0) {
    error.textContent =
      "This OTP has expired. Please resend a new OTP.";
    error.hidden = false;
    return;
  }

  if (otp !== generatedOTP) {
    error.textContent = "Incorrect OTP. Please try again.";
    error.hidden = false;
    return;
  }

  clearInterval(otpTimer);

  error.hidden = true;

  renderBallot();

  goToStep(4);
}

/* -----------------------------
   Ballot
----------------------------- */

function renderBallot() {
  const ballot = $("#ballot-list");

  ballot.innerHTML = "";

  CANDIDATES.forEach((candidate) => {
    const label = document.createElement("label");

    label.className = "ballot-option";

    label.innerHTML = `
      <input
        type="radio"
        name="candidate"
        value="${candidate.id}"
      >

      <div>
        <span class="candidate-name">
          ${candidate.name}
        </span>

        <span class="candidate-party">
          ${candidate.party}
        </span>
      </div>
    `;

    ballot.appendChild(label);
  });

  $$("#ballot-list input").forEach((radio) => {
    radio.addEventListener("change", () => {
      currentCandidate = CANDIDATES.find(
        (candidate) => candidate.id === radio.value
      );

      $$(".ballot-option").forEach((option) => {
        option.classList.remove("selected");
      });

      radio.closest(".ballot-option").classList.add("selected");

      $("#btn-cast").disabled = false;
    });
  });

  currentCandidate = null;
  $("#btn-cast").disabled = true;
}

/* -----------------------------
   Cast vote
----------------------------- */

function castVote() {
  if (!currentCandidate) {
    alert("Please select a candidate first.");
    return;
  }

  results[currentCandidate.id]++;

  $("#receipt-name").textContent =
    currentVoter?.name || "Demo Voter";

  $("#receipt-choice").textContent =
    `${currentCandidate.name} — ${currentCandidate.party}`;

  $("#receipt-time").textContent =
    new Date().toLocaleString();

  $("#confirm-message").textContent =
    `Your demo vote for ${currentCandidate.name} has been recorded.`;

  renderResults();

  goToStep(5);
}

/* -----------------------------
   Results
----------------------------- */

function renderResults() {
  const resultsList = $("#results-list");

  resultsList.innerHTML = "";

  CANDIDATES.forEach((candidate) => {
    const row = document.createElement("div");

    row.className = "result-row";

    row.innerHTML = `
      <span class="result-name">
        ${candidate.name}
      </span>

      <span class="result-votes">
        ${results[candidate.id]} votes
      </span>
    `;

    resultsList.appendChild(row);
  });
}

/* -----------------------------
   Restart
----------------------------- */

function restartDemo() {
  clearInterval(otpTimer);

  if (cameraStream) {
    cameraStream.getTracks().forEach((track) => track.stop());
    cameraStream = null;
  }

  currentStep = 1;
  currentVoter = null;
  currentCandidate = null;
  generatedOTP = "";
  otpSeconds = 60;
  hasFaceVerification = false;

  $("#login-voter-id").value = "";
  $("#login-password").value = "";

  $("#login-error").hidden = true;
  $("#otp-error").hidden = true;

  $("#demo-otp-code").textContent = "------";
  $("#otp-timer").textContent = "60";

  $("#camera-feed").srcObject = null;
  $("#camera-placeholder").style.display = "grid";

  $("#btn-camera").textContent = "Turn On Camera";

  $("#btn-verify-face").disabled = true;
  $("#btn-verify-face").textContent = "Verify Face";

  $("#face-status").textContent =
    "Camera access is optional for this educational demo.";

  $("#btn-cast").disabled = true;

  goToStep(1);
}

/* -----------------------------
   OTP input behavior
----------------------------- */

function setupOTPInputs() {
  const inputs = $$(".otp-box");

  inputs.forEach((input, index) => {
    input.addEventListener("input", (event) => {
      event.target.value = event.target.value
        .replace(/\D/g, "")
        .slice(0, 1);

      if (event.target.value && index < inputs.length - 1) {
        inputs[index + 1].focus();
      }
    });

    input.addEventListener("keydown", (event) => {
      if (
        event.key === "Backspace" &&
        !input.value &&
        index > 0
      ) {
        inputs[index - 1].focus();
      }
    });

    input.addEventListener("paste", (event) => {
      event.preventDefault();

      const pasted = (
        event.clipboardData ||
        window.clipboardData
      )
        .getData("text")
        .replace(/\D/g, "")
        .slice(0, 6);

      pasted.split("").forEach((digit, i) => {
        if (inputs[i]) {
          inputs[i].value = digit;
        }
      });

      const lastIndex = Math.min(
        pasted.length,
        inputs.length
      ) - 1;

      if (lastIndex >= 0) {
        inputs[lastIndex].focus();
      }
    });
  });
}

/* -----------------------------
   Event listeners
----------------------------- */

document.addEventListener("DOMContentLoaded", () => {
  $("#btn-login").addEventListener("click", login);

  $("#forgot-password").addEventListener(
    "click",
    forgotPassword
  );

  $("#btn-camera").addEventListener(
    "click",
    turnOnCamera
  );

  $("#btn-verify-face").addEventListener(
    "click",
    verifyFace
  );

  $("#btn-verify-otp").addEventListener(
    "click",
    verifyOTP
  );

  $("#btn-resend-otp").addEventListener(
    "click",
    resendOTP
  );

  $("#btn-cast").addEventListener(
    "click",
    castVote
  );

  $("#btn-restart").addEventListener(
    "click",
    restartDemo
  );

  setupOTPInputs();

  renderResults();

  /* Allow Enter key on login */
  $("#login-voter-id").addEventListener(
    "keydown",
    (event) => {
      if (event.key === "Enter") {
        login();
      }
    }
  );

  $("#login-password").addEventListener(
    "keydown",
    (event) => {
      if (event.key === "Enter") {
        login();
      }
    }
  );
});