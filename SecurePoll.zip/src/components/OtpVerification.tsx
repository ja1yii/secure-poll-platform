import React, { useState, useEffect, useRef } from 'react';
import { KeyRound, ShieldCheck, RefreshCw, AlertCircle, CheckCircle2, Smartphone } from 'lucide-react';
import { Voter } from '../types';
import { SmsToast } from './SmsToast';
import { playSuccessChime, playErrorSound } from '../services/audio';

interface OtpVerificationProps {
  voter: Voter;
  onVerified: () => void;
  onBack?: () => void;
}

export const OtpVerification: React.FC<OtpVerificationProps> = ({
  voter,
  onVerified,
  onBack
}) => {
  const [generatedOtp, setGeneratedOtp] = useState<string>('');
  const [digits, setDigits] = useState<string[]>(['', '', '', '', '', '']);
  const [timeLeft, setTimeLeft] = useState<number>(60);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [showSmsToast, setShowSmsToast] = useState<boolean>(true);

  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Generate random 6-digit OTP
  const createNewOtp = () => {
    const code = String(Math.floor(100000 + Math.random() * 900000));
    setGeneratedOtp(code);
    setTimeLeft(60);
    setDigits(['', '', '', '', '', '']);
    setErrorMsg(null);
    setShowSmsToast(true);

    setTimeout(() => {
      inputRefs.current[0]?.focus();
    }, 100);
  };

  useEffect(() => {
    createNewOtp();
  }, []);

  // Timer countdown
  useEffect(() => {
    if (timeLeft <= 0) return;
    const interval = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [timeLeft]);

  // Handle single digit input
  const handleDigitChange = (index: number, value: string) => {
    // Only accept numeric digit
    const cleaned = value.replace(/\D/g, '').slice(-1);
    const updated = [...digits];
    updated[index] = cleaned;
    setDigits(updated);
    setErrorMsg(null);

    // Auto advance focus
    if (cleaned && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  // Handle backspace key
  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !digits[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    } else if (e.key === 'Enter') {
      submitOtp();
    }
  };

  // Handle paste full code
  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    if (!pasted) return;

    const updated = [...digits];
    for (let i = 0; i < 6; i++) {
      updated[i] = pasted[i] || '';
    }
    setDigits(updated);

    const targetIdx = Math.min(pasted.length, 5);
    inputRefs.current[targetIdx]?.focus();
  };

  // Submit and verify
  const submitOtp = () => {
    const entered = digits.join('');

    if (entered.length < 6) {
      setErrorMsg('Please enter all 6 digits of your one-time verification code.');
      playErrorSound();
      return;
    }

    if (timeLeft <= 0) {
      setErrorMsg('This OTP code has expired. Please click "Resend OTP" to generate a fresh code.');
      playErrorSound();
      return;
    }

    if (entered !== generatedOtp) {
      setErrorMsg('Invalid OTP entered. Please check the code sent to your phone or use 1-Click Auto-Fill.');
      playErrorSound();
      return;
    }

    setIsVerifying(true);
    playSuccessChime();

    setTimeout(() => {
      setIsVerifying(false);
      onVerified();
    }, 600);
  };

  const handleAutofill = (code: string) => {
    const chars = code.split('').slice(0, 6);
    setDigits(chars);
    setErrorMsg(null);
    inputRefs.current[5]?.focus();
  };

  return (
    <>
      {showSmsToast && generatedOtp && (
        <SmsToast
          code={generatedOtp}
          phone={voter.phone}
          onAutofill={handleAutofill}
          onClose={() => setShowSmsToast(false)}
        />
      )}

      <div className="bg-white rounded-2xl shadow-xl border border-neutral-200/80 overflow-hidden max-w-xl mx-auto">
        {/* Header */}
        <div className="bg-emerald-950 text-white px-6 py-5 flex items-center justify-between border-b border-emerald-900/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display text-xl font-bold tracking-tight text-white">2-Factor OTP Verification</h3>
              <p className="text-xs text-emerald-300/80 font-medium">Step 3 of 5: SMS Authentication</p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-emerald-900/60 text-emerald-200 border border-emerald-700/50 text-xs px-3 py-1.5 rounded-full font-mono">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>2FA SECURED</span>
          </div>
        </div>

        <div className="p-6 md:p-8 space-y-6 text-center">
          {/* Phone recipient notification */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-50 border border-emerald-200/80 text-emerald-900 text-xs font-medium">
            <Smartphone className="w-4 h-4 text-emerald-700" />
            <span>Code dispatched to registered phone: <strong>{voter.phone}</strong></span>
          </div>

          <div className="space-y-1">
            <h4 className="text-lg font-bold text-neutral-900">Enter Your 6-Digit Electoral Code</h4>
            <p className="text-xs text-neutral-500 max-w-md mx-auto">
              Please enter the temporary passcode sent via encrypted SMS. This code confirms you are the authorized ballot holder.
            </p>
          </div>

          {/* 6 Individual Digit Boxes */}
          <div className="flex justify-center items-center gap-2.5 sm:gap-3.5 my-4" onPaste={handlePaste}>
            {digits.map((digit, idx) => (
              <input
                key={idx}
                ref={el => { inputRefs.current[idx] = el; }}
                type="text"
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={1}
                value={digit}
                onChange={e => handleDigitChange(idx, e.target.value)}
                onKeyDown={e => handleKeyDown(idx, e)}
                className={`w-11 h-14 sm:w-13 sm:h-16 text-center text-2xl font-mono font-bold rounded-xl border-2 transition-all outline-none ${
                  digit
                    ? 'border-emerald-600 bg-emerald-50/50 text-emerald-950 shadow-sm'
                    : 'border-neutral-300 bg-white text-neutral-900 focus:border-emerald-600 focus:ring-4 focus:ring-emerald-500/10'
                }`}
              />
            ))}
          </div>

          {/* Error Message */}
          {errorMsg && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-center justify-center gap-2 text-xs font-semibold text-red-700 animate-in fade-in">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Timer and Demo Code Helper */}
          <div className="bg-neutral-50 rounded-xl p-4 border border-neutral-200/70 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-neutral-600 flex items-center gap-1.5 font-medium">
                <span className={`w-2 h-2 rounded-full ${timeLeft > 0 ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'}`}></span>
                {timeLeft > 0 ? `Code expires in ${timeLeft}s` : 'Code expired'}
              </span>
              <button
                type="button"
                disabled={timeLeft > 40}
                onClick={createNewOtp}
                className="text-emerald-700 font-bold hover:underline disabled:opacity-40 disabled:no-underline flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" />
                Resend OTP
              </button>
            </div>

            <div className="pt-2 border-t border-neutral-200/60 flex items-center justify-between text-xs">
              <span className="text-neutral-500">Live Generated Code:</span>
              <div className="flex items-center gap-2">
                <span className="font-mono font-bold text-emerald-800 text-sm tracking-wider bg-emerald-100/70 px-2 py-0.5 rounded">
                  {generatedOtp}
                </span>
                <button
                  type="button"
                  onClick={() => handleAutofill(generatedOtp)}
                  className="text-[11px] text-emerald-700 hover:text-emerald-900 font-semibold underline cursor-pointer"
                >
                  Fill
                </button>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
            <button
              type="button"
              disabled={isVerifying || digits.some(d => d === '')}
              onClick={submitOtp}
              className="w-full sm:flex-1 py-3.5 px-6 rounded-xl bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white font-bold text-sm tracking-wide shadow-lg shadow-emerald-900/15 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              {isVerifying ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Verifying OTP...
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  Verify & Open Official Ballot
                </>
              )}
            </button>

            {onBack && (
              <button
                type="button"
                onClick={onBack}
                className="w-full sm:w-auto py-3.5 px-5 rounded-xl border border-neutral-300 hover:bg-neutral-50 text-neutral-600 font-medium text-sm transition-all cursor-pointer"
              >
                Back
              </button>
            )}
          </div>
        </div>
      </div>
    </>
  );
};
