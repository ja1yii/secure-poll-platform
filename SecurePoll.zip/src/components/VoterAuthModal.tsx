import React, { useState, useRef } from 'react';
import { User, Lock, Mail, Phone, Calendar, MapPin, Camera, CheckCircle2, AlertCircle, Eye, EyeOff, Sparkles, X, Shield, RefreshCw } from 'lucide-react';
import { Voter } from '../types';
import { registerVoter, loginVoter } from '../services/storage';
import { playSuccessChime, playErrorSound } from '../services/audio';

interface VoterAuthModalProps {
  isOpen: boolean;
  initialTab?: 'LOGIN' | 'REGISTER';
  onClose: () => void;
  onSuccess: (voter: Voter) => void;
}

const SAMPLE_AVATARS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80'
];

export const VoterAuthModal: React.FC<VoterAuthModalProps> = ({
  isOpen,
  initialTab = 'LOGIN',
  onClose,
  onSuccess
}) => {
  const [tab, setTab] = useState<'LOGIN' | 'REGISTER'>(initialTab);

  // Login form state
  const [loginId, setLoginId] = useState<string>('VOT-2026-0341');
  const [loginPassword, setLoginPassword] = useState<string>('Vote@123');
  const [showLoginPassword, setShowLoginPassword] = useState<boolean>(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  // Register form state
  const [regName, setRegName] = useState<string>('');
  const [regVoterId, setRegVoterId] = useState<string>('');
  const [regEmail, setRegEmail] = useState<string>('');
  const [regPhone, setRegPhone] = useState<string>('+91 ');
  const [regDob, setRegDob] = useState<string>('2001-04-18');
  const [regConstituency, setRegConstituency] = useState<string>('Central District 04');
  const [regPassword, setRegPassword] = useState<string>('');
  const [regConfirmPassword, setRegConfirmPassword] = useState<string>('');
  const [regPhotoUrl, setRegPhotoUrl] = useState<string>(SAMPLE_AVATARS[0]);
  const [regError, setRegError] = useState<string | null>(null);

  // Camera capture modal state inside registration
  const [showCameraCapture, setShowCameraCapture] = useState<boolean>(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const videoCaptureRef = useRef<HTMLVideoElement | null>(null);
  const canvasCaptureRef = useRef<HTMLCanvasElement | null>(null);

  if (!isOpen) return null;

  // Generate random certified voter ID
  const generateVoterId = () => {
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    setRegVoterId(`VOT-2026-${randomNum}`);
  };

  // Handle Login submission
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    if (!loginId.trim() || !loginPassword) {
      setLoginError('Please provide both your Voter ID/Email and password.');
      playErrorSound();
      return;
    }

    const result = loginVoter(loginId, loginPassword);
    if (!result.success || !result.voter) {
      setLoginError(result.error || 'Authentication failed.');
      playErrorSound();
      return;
    }

    playSuccessChime();
    onSuccess(result.voter);
    onClose();
  };

  // Quick fill demo user
  const fillDemoAccount = (id: string, pass: string) => {
    setLoginId(id);
    setLoginPassword(pass);
    setLoginError(null);
  };

  // Handle Register submission
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError(null);

    if (!regName.trim()) {
      setRegError('Please enter your full legal name as per government records.');
      playErrorSound();
      return;
    }

    const voterIdToUse = regVoterId.trim() || `VOT-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    if (!regEmail.trim() || !regEmail.includes('@')) {
      setRegError('Please provide a valid email address.');
      playErrorSound();
      return;
    }

    if (!regPhone.trim() || regPhone.length < 8) {
      setRegError('Please provide a valid mobile number for receiving OTP verification.');
      playErrorSound();
      return;
    }

    if (!regPassword || regPassword.length < 6) {
      setRegError('Password must be at least 6 characters long.');
      playErrorSound();
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setRegError('Passwords do not match. Please verify.');
      playErrorSound();
      return;
    }

    const result = registerVoter({
      id: voterIdToUse.toUpperCase(),
      name: regName.trim(),
      email: regEmail.trim(),
      phone: regPhone.trim(),
      password: regPassword,
      dob: regDob,
      constituency: regConstituency,
      facePhotoUrl: regPhotoUrl
    });

    if (!result.success || !result.voter) {
      setRegError(result.error || 'Registration failed.');
      playErrorSound();
      return;
    }

    playSuccessChime();
    onSuccess(result.voter);
    onClose();
  };

  // Open camera for registration snapshot
  const startEnrollmentCamera = async () => {
    setShowCameraCapture(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: 480, height: 480 },
        audio: false
      });
      setCameraStream(stream);
      if (videoCaptureRef.current) {
        videoCaptureRef.current.srcObject = stream;
        videoCaptureRef.current.play();
      }
    } catch (err) {
      console.warn('Registration camera access error:', err);
    }
  };

  const captureEnrollmentSnapshot = () => {
    const video = videoCaptureRef.current;
    const canvas = canvasCaptureRef.current;
    if (video && canvas) {
      canvas.width = 320;
      canvas.height = 320;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, 320, 320);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        setRegPhotoUrl(dataUrl);
      }
    }
    stopEnrollmentCamera();
  };

  const stopEnrollmentCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(t => t.stop());
      setCameraStream(null);
    }
    setShowCameraCapture(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl border border-neutral-200 overflow-hidden my-8 animate-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="bg-emerald-950 text-white px-6 py-5 flex items-center justify-between border-b border-emerald-900/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display text-xl font-bold tracking-tight text-white">Electoral Voter Access</h3>
              <p className="text-xs text-emerald-300/80 font-medium">National Democratic Authentication Gateway</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-emerald-900/60 text-emerald-300 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="grid grid-cols-2 border-b border-neutral-200 bg-neutral-50/70 p-1">
          <button
            type="button"
            onClick={() => setTab('LOGIN')}
            className={`py-3 text-xs sm:text-sm font-bold rounded-xl transition-all cursor-pointer ${
              tab === 'LOGIN'
                ? 'bg-white text-emerald-950 shadow-sm border border-neutral-200/80'
                : 'text-neutral-500 hover:text-neutral-800'
            }`}
          >
            Existing Voter Login
          </button>
          <button
            type="button"
            onClick={() => {
              setTab('REGISTER');
              if (!regVoterId) generateVoterId();
            }}
            className={`py-3 text-xs sm:text-sm font-bold rounded-xl transition-all cursor-pointer ${
              tab === 'REGISTER'
                ? 'bg-white text-emerald-950 shadow-sm border border-neutral-200/80'
                : 'text-neutral-500 hover:text-neutral-800'
            }`}
          >
            New Voter Registration
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8">
          {/* TAB 1: LOGIN */}
          {tab === 'LOGIN' && (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div className="text-left space-y-1 pb-1">
                <h4 className="text-base font-bold text-neutral-900">Sign in to Your Voter Account</h4>
                <p className="text-xs text-neutral-500">
                  Enter your assigned Voter ID number or registered email to begin identity verification.
                </p>
              </div>

              {loginError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-center gap-2 text-xs font-semibold text-red-700 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{loginError}</span>
                </div>
              )}

              {/* Voter ID field */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-neutral-700">
                  Voter ID or Registered Email
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={loginId}
                    onChange={e => setLoginId(e.target.value)}
                    placeholder="e.g. VOT-2026-0341"
                    className="w-full pl-10 pr-4 py-3 rounded-xl border border-neutral-300 text-sm focus:border-emerald-600 focus:ring-4 focus:ring-emerald-500/10 outline-none transition-all font-mono"
                  />
                </div>
              </div>

              {/* Password field */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-neutral-700">
                    Password
                  </label>
                  <button
                    type="button"
                    onClick={() => alert("Password Recovery Assistance:\nFor registered demo voters, default password is: Vote@123.\nIn production, a cryptographic reset token is dispatched via government SMS.")}
                    className="text-xs text-emerald-700 hover:underline font-semibold"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type={showLoginPassword ? 'text' : 'password'}
                    required
                    value={loginPassword}
                    onChange={e => setLoginPassword(e.target.value)}
                    placeholder="Enter account password"
                    className="w-full pl-10 pr-10 py-3 rounded-xl border border-neutral-300 text-sm focus:border-emerald-600 focus:ring-4 focus:ring-emerald-500/10 outline-none transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowLoginPassword(!showLoginPassword)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-700"
                  >
                    {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-sm font-bold shadow-lg shadow-emerald-950/10 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Lock className="w-4 h-4" />
                Authenticate & Open Voting Session
              </button>

              {/* Demo Credentials Box */}
              <div className="pt-3 border-t border-neutral-100">
                <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider block mb-2">
                  Instant One-Click Demo Credentials:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => fillDemoAccount('VOT-2026-0341', 'Vote@123')}
                    className="p-2.5 rounded-xl bg-emerald-50/70 hover:bg-emerald-100/70 border border-emerald-200 text-left transition-all cursor-pointer"
                  >
                    <div className="font-bold text-emerald-950">Asha Verma</div>
                    <div className="font-mono text-[11px] text-emerald-800">VOT-2026-0341 • Vote@123</div>
                  </button>
                  <button
                    type="button"
                    onClick={() => fillDemoAccount('VOT-2026-0892', 'Vote@123')}
                    className="p-2.5 rounded-xl bg-emerald-50/70 hover:bg-emerald-100/70 border border-emerald-200 text-left transition-all cursor-pointer"
                  >
                    <div className="font-bold text-emerald-950">Rajesh Khurana</div>
                    <div className="font-mono text-[11px] text-emerald-800">VOT-2026-0892 • Vote@123</div>
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* TAB 2: REGISTER */}
          {tab === 'REGISTER' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-4 text-left">
              <div className="space-y-1 pb-1">
                <h4 className="text-base font-bold text-neutral-900">Enroll as a Certified Voter</h4>
                <p className="text-xs text-neutral-500">
                  Register your legal credentials, mobile number for 2FA, and facial biometric template.
                </p>
              </div>

              {regError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-center gap-2 text-xs font-semibold text-red-700 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{regError}</span>
                </div>
              )}

              {/* Full Name & Voter ID */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-neutral-700">Full Legal Name</label>
                  <input
                    type="text"
                    required
                    value={regName}
                    onChange={e => setRegName(e.target.value)}
                    placeholder="e.g. Sunil Deshmukh"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 text-sm focus:border-emerald-600 outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="block text-xs font-bold text-neutral-700">Voter ID Card #</label>
                    <button
                      type="button"
                      onClick={generateVoterId}
                      className="text-[10px] text-emerald-700 font-bold hover:underline"
                    >
                      Regenerate
                    </button>
                  </div>
                  <input
                    type="text"
                    required
                    value={regVoterId}
                    onChange={e => setRegVoterId(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 text-sm font-mono focus:border-emerald-600 outline-none uppercase"
                  />
                </div>
              </div>

              {/* Email & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-neutral-700">Email Address</label>
                  <input
                    type="email"
                    required
                    value={regEmail}
                    onChange={e => setRegEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 text-sm focus:border-emerald-600 outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-neutral-700">Mobile Phone (for OTP)</label>
                  <input
                    type="tel"
                    required
                    value={regPhone}
                    onChange={e => setRegPhone(e.target.value)}
                    placeholder="+91 98765 00000"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 text-sm font-mono focus:border-emerald-600 outline-none"
                  />
                </div>
              </div>

              {/* DOB & Constituency */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-neutral-700">Date of Birth</label>
                  <input
                    type="date"
                    required
                    value={regDob}
                    onChange={e => setRegDob(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 text-sm focus:border-emerald-600 outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-neutral-700">Electoral Constituency</label>
                  <select
                    value={regConstituency}
                    onChange={e => setRegConstituency(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 text-sm focus:border-emerald-600 outline-none bg-white"
                  >
                    <option value="Central District 04">Central District 04</option>
                    <option value="North Metro 02">North Metro 02</option>
                    <option value="South Riverside 09">South Riverside 09</option>
                    <option value="Civic Ward 12">Civic Ward 12</option>
                  </select>
                </div>
              </div>

              {/* Biometric Face Profile Selection / Webcam Capture */}
              <div className="p-3.5 bg-neutral-50 rounded-2xl border border-neutral-200/80 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-neutral-900 block">Biometric Facial Profile</span>
                    <span className="text-[11px] text-neutral-500">Capture with your webcam or pick an official avatar</span>
                  </div>
                  <button
                    type="button"
                    onClick={startEnrollmentCamera}
                    className="px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
                  >
                    <Camera className="w-3.5 h-3.5" />
                    Take Live Photo
                  </button>
                </div>

                <div className="flex items-center gap-3 pt-1">
                  <div className="relative shrink-0">
                    <img
                      src={regPhotoUrl}
                      alt="Biometric Preview"
                      className="w-14 h-14 rounded-xl object-cover border-2 border-emerald-600 shadow-sm"
                    />
                    <span className="absolute -bottom-1 -right-1 bg-emerald-600 text-white rounded-full p-0.5 text-[9px]">
                      <CheckCircle2 className="w-3 h-3" />
                    </span>
                  </div>

                  <div className="flex-1">
                    <span className="text-[10px] text-neutral-400 block mb-1">Preset Certified Profiles:</span>
                    <div className="flex gap-2">
                      {SAMPLE_AVATARS.map((url, i) => (
                        <button
                          key={i}
                          type="button"
                          onClick={() => setRegPhotoUrl(url)}
                          className={`w-9 h-9 rounded-lg overflow-hidden border-2 transition-all cursor-pointer ${
                            regPhotoUrl === url ? 'border-emerald-600 scale-105 shadow-sm' : 'border-neutral-200 opacity-60 hover:opacity-100'
                          }`}
                        >
                          <img src={url} alt="preset" className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Password & Confirm */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-neutral-700">Account Password</label>
                  <input
                    type="password"
                    required
                    value={regPassword}
                    onChange={e => setRegPassword(e.target.value)}
                    placeholder="Min 6 characters"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 text-sm focus:border-emerald-600 outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-neutral-700">Confirm Password</label>
                  <input
                    type="password"
                    required
                    value={regConfirmPassword}
                    onChange={e => setRegConfirmPassword(e.target.value)}
                    placeholder="Repeat password"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 text-sm focus:border-emerald-600 outline-none"
                  />
                </div>
              </div>

              {/* Submit */}
              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-sm font-bold shadow-lg shadow-emerald-950/10 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                Complete Registration & Issue Digital Voter Card
              </button>
            </form>
          )}
        </div>
      </div>

      {/* Embedded Live Snapshot Capture Modal */}
      {showCameraCapture && (
        <div className="fixed inset-0 z-60 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-neutral-900 text-white rounded-2xl max-w-sm w-full p-5 space-y-4 border border-neutral-700">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-sm flex items-center gap-2 text-emerald-400">
                <Camera className="w-4 h-4" />
                Live Biometric Photo Capture
              </h4>
              <button onClick={stopEnrollmentCamera} className="text-neutral-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <canvas ref={canvasCaptureRef} className="hidden" />

            <div className="w-full aspect-square bg-black rounded-xl overflow-hidden relative border border-neutral-800 flex items-center justify-center">
              <video
                ref={videoCaptureRef}
                playsInline
                muted
                className="w-full h-full object-cover transform -scale-x-100"
              />
              <div className="absolute inset-0 pointer-events-none border-2 border-dashed border-emerald-400/60 rounded-full m-8"></div>
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={captureEnrollmentSnapshot}
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5"
              >
                <Camera className="w-4 h-4" />
                Snap Photo
              </button>
              <button
                type="button"
                onClick={stopEnrollmentCamera}
                className="py-2.5 px-4 rounded-xl bg-neutral-800 text-neutral-300 text-xs font-medium hover:bg-neutral-700"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
