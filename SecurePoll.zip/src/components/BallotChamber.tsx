import React, { useState } from 'react';
import { Vote, Check, ShieldCheck, Lock, AlertTriangle, FileText, ChevronDown, ChevronUp, UserCheck } from 'lucide-react';
import { Candidate, Election, Voter } from '../types';
import { playSuccessChime } from '../services/audio';

interface BallotChamberProps {
  election: Election;
  voter: Voter;
  onCastVote: (candidateId: string) => void;
  onCancel?: () => void;
}

export const BallotChamber: React.FC<BallotChamberProps> = ({
  election,
  voter,
  onCastVote,
  onCancel
}) => {
  const [selectedCandidateId, setSelectedCandidateId] = useState<string | null>(null);
  const [expandedManifestoId, setExpandedManifestoId] = useState<string | null>(null);
  const [showConfirmModal, setShowConfirmModal] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const selectedCandidate = election.candidates.find(c => c.id === selectedCandidateId);

  const handleSelect = (id: string) => {
    setSelectedCandidateId(id);
  };

  const handleOpenConfirm = () => {
    if (!selectedCandidateId) return;
    setShowConfirmModal(true);
  };

  const handleFinalCast = () => {
    if (!selectedCandidateId) return;
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setShowConfirmModal(false);
      onCastVote(selectedCandidateId);
    }, 700);
  };

  return (
    <>
      <div className="bg-white rounded-2xl shadow-xl border border-neutral-200/80 overflow-hidden max-w-3xl mx-auto">
        {/* Chamber Header */}
        <div className="bg-emerald-950 text-white px-6 py-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-emerald-900/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400">
              <Vote className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display text-xl font-bold tracking-tight text-white">Secret Electoral Ballot</h3>
              <p className="text-xs text-emerald-300/80 font-medium">Step 4 of 5: Official Candidate Selection</p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-emerald-900/60 text-emerald-200 border border-emerald-700/50 text-xs px-3 py-1.5 rounded-full font-mono">
            <Lock className="w-3.5 h-3.5 text-emerald-400" />
            <span>ENCRYPTED BALLOT</span>
          </div>
        </div>

        {/* Election & Voter Info Banner */}
        <div className="p-6 bg-gradient-to-r from-emerald-50/70 to-neutral-50 border-b border-neutral-200/70 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-[11px] font-bold tracking-wider text-emerald-800 uppercase bg-emerald-100/70 px-2.5 py-0.5 rounded-full border border-emerald-200">
              {election.category}
            </span>
            <h4 className="text-base font-bold text-neutral-900 mt-1">{election.title}</h4>
            <p className="text-xs text-neutral-600 mt-0.5">Constituency: <strong>{voter.constituency}</strong> • Single-Choice Plurality</p>
          </div>

          <div className="flex items-center gap-2.5 bg-white px-3.5 py-2 rounded-xl border border-neutral-200/80 text-xs">
            <UserCheck className="w-4 h-4 text-emerald-600" />
            <div>
              <div className="font-bold text-neutral-900">{voter.name}</div>
              <div className="text-[11px] text-neutral-500 font-mono">Biometrics & 2FA Cleared</div>
            </div>
          </div>
        </div>

        {/* Candidate List */}
        <div className="p-6 md:p-8 space-y-4">
          <div className="flex items-center justify-between text-xs text-neutral-500 pb-1">
            <span>Select one certified candidate or NOTA:</span>
            <span>{election.candidates.length} options on ballot</span>
          </div>

          <div className="grid gap-3.5">
            {election.candidates.map((candidate) => {
              const isSelected = selectedCandidateId === candidate.id;
              const isExpanded = expandedManifestoId === candidate.id;

              return (
                <div
                  key={candidate.id}
                  onClick={() => handleSelect(candidate.id)}
                  className={`rounded-2xl border-2 transition-all cursor-pointer overflow-hidden ${
                    isSelected
                      ? 'border-emerald-600 bg-emerald-50/40 shadow-md ring-2 ring-emerald-500/10'
                      : 'border-neutral-200 bg-white hover:border-neutral-300 hover:bg-neutral-50/50'
                  }`}
                >
                  <div className="p-4 sm:p-5 flex items-start gap-4">
                    {/* Selection Radio / Check Indicator */}
                    <div className="pt-1">
                      <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                        isSelected
                          ? 'border-emerald-600 bg-emerald-600 text-white shadow-sm'
                          : 'border-neutral-300 bg-white'
                      }`}>
                        {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                    </div>

                    {/* Candidate Photo / Symbol */}
                    <div className="relative shrink-0">
                      <img
                        src={candidate.photoUrl}
                        alt={candidate.name}
                        className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl object-cover border border-neutral-200"
                      />
                      <span className="absolute -bottom-1 -right-1 text-base bg-white shadow-sm rounded-full p-0.5 border border-neutral-200">
                        {candidate.symbol}
                      </span>
                    </div>

                    {/* Candidate Details */}
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <h4 className="text-base font-bold text-neutral-900">{candidate.name}</h4>
                        <span
                          className="text-[11px] font-semibold px-2 py-0.5 rounded-full text-white"
                          style={{ backgroundColor: candidate.partyColor }}
                        >
                          {candidate.party}
                        </span>
                      </div>

                      <p className="text-xs text-neutral-600 mt-1 line-clamp-2">
                        {candidate.bio}
                      </p>

                      {/* Manifesto toggle button */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setExpandedManifestoId(isExpanded ? null : candidate.id);
                        }}
                        className="mt-2 text-[11px] font-semibold text-emerald-700 hover:text-emerald-900 flex items-center gap-1 cursor-pointer"
                      >
                        <FileText className="w-3 h-3" />
                        {isExpanded ? 'Hide Agenda Promises' : 'View Key Agenda Promises'}
                        {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                      </button>
                    </div>
                  </div>

                  {/* Expandable Manifesto Drawer */}
                  {isExpanded && (
                    <div className="px-5 pb-4 pt-1 bg-neutral-50/80 border-t border-neutral-100 text-xs text-neutral-700 space-y-1.5 animate-in fade-in duration-200">
                      <div className="font-semibold text-neutral-900 text-[11px] uppercase tracking-wider text-emerald-800">
                        Certified Manifesto Commitments:
                      </div>
                      <ul className="list-disc pl-5 space-y-1">
                        {candidate.manifesto.map((item, idx) => (
                          <li key={idx}>{item}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Privacy Disclaimer */}
          <div className="p-3.5 bg-neutral-50 rounded-xl border border-neutral-200 flex items-center gap-3 text-xs text-neutral-600">
            <Lock className="w-4 h-4 text-emerald-700 shrink-0" />
            <p>
              <strong>Secret Ballot Guarantee:</strong> Your vote is cryptographically decoupled from your identity. Only an anonymous receipt hash is placed on the public electoral ledger.
            </p>
          </div>

          {/* Cast Vote CTA */}
          <div className="flex flex-col sm:flex-row items-center gap-3 pt-3">
            <button
              type="button"
              disabled={!selectedCandidateId}
              onClick={handleOpenConfirm}
              className="w-full sm:flex-1 py-4 px-6 rounded-xl bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white font-bold text-sm tracking-wide shadow-lg shadow-emerald-900/15 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Vote className="w-4 h-4" />
              {selectedCandidate
                ? `Proceed to Cast Ballot for ${selectedCandidate.name}`
                : 'Select a Candidate to Proceed'}
            </button>

            {onCancel && (
              <button
                type="button"
                onClick={onCancel}
                className="w-full sm:w-auto py-4 px-5 rounded-xl border border-neutral-300 hover:bg-neutral-50 text-neutral-600 font-medium text-sm transition-all cursor-pointer"
              >
                Cancel Session
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Confirmation Modal */}
      {showConfirmModal && selectedCandidate && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-neutral-200 space-y-5 animate-in zoom-in-95 duration-200">
            <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
              <Vote className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1.5">
              <h3 className="font-display text-xl font-bold text-neutral-900">Confirm Your Official Vote</h3>
              <p className="text-xs text-neutral-500">
                Please verify your selection carefully. Electoral law states this ballot cannot be modified once sealed.
              </p>
            </div>

            {/* Candidate Card Review */}
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200/80 flex items-center gap-3">
              <img
                src={selectedCandidate.photoUrl}
                alt={selectedCandidate.name}
                className="w-12 h-12 rounded-lg object-cover border border-emerald-600/30"
              />
              <div className="min-w-0">
                <div className="text-sm font-bold text-emerald-950">{selectedCandidate.name}</div>
                <div className="text-xs text-emerald-700 font-medium">{selectedCandidate.party}</div>
              </div>
            </div>

            <div className="p-3 bg-neutral-50 rounded-xl text-xs text-neutral-600 space-y-1 font-mono">
              <div className="flex justify-between">
                <span>VOTER:</span>
                <span className="font-semibold text-neutral-900">{voter.name} ({voter.id})</span>
              </div>
              <div className="flex justify-between">
                <span>SECURITY:</span>
                <span className="text-emerald-700 font-semibold">Face Biometric + SMS 2FA</span>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                disabled={isSubmitting}
                onClick={handleFinalCast}
                className="flex-1 py-3 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-sm cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? 'Encrypting & Sealing Ballot...' : 'Yes, Confirm & Cast Vote'}
              </button>
              <button
                type="button"
                disabled={isSubmitting}
                onClick={() => setShowConfirmModal(false)}
                className="py-3 px-4 rounded-xl border border-neutral-300 text-neutral-700 text-xs font-semibold hover:bg-neutral-50 transition-all cursor-pointer"
              >
                Change Choice
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
