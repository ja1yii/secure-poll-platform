import React from 'react';
import { ShieldCheck, User, LogOut, IdCard, Sparkles, RefreshCw, BarChart2, CheckCircle2 } from 'lucide-react';
import { Voter } from '../types';

interface NavbarProps {
  currentVoter: Voter | null;
  activeTab: 'HOME' | 'VOTE' | 'RESULTS' | 'AUDIT';
  onNavigate: (tab: 'HOME' | 'VOTE' | 'RESULTS' | 'AUDIT') => void;
  onOpenLogin: () => void;
  onOpenRegister: () => void;
  onOpenVoterCard: () => void;
  onLogout: () => void;
  onResetDemo: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentVoter,
  activeTab,
  onNavigate,
  onOpenLogin,
  onOpenRegister,
  onOpenVoterCard,
  onLogout,
  onResetDemo
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-neutral-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
        {/* Brand */}
        <div className="flex items-center gap-8">
          <button
            type="button"
            onClick={() => onNavigate('HOME')}
            className="flex items-center gap-2.5 text-left group cursor-pointer"
          >
            <span className="w-9 h-9 rounded-full bg-emerald-700 group-hover:bg-emerald-800 text-white flex items-center justify-center font-bold text-sm shadow-md transition-transform group-hover:scale-105">
              ✓
            </span>
            <div>
              <span className="font-display font-bold text-xl text-emerald-950 tracking-tight block">
                SecurePoll
              </span>
              <span className="text-[10px] font-mono tracking-wider text-emerald-700 font-semibold block -mt-1 uppercase">
                Biometric & 2FA E-Voting
              </span>
            </div>
          </button>

          {/* Nav Links */}
          <nav className="hidden md:flex items-center gap-1 text-xs font-bold text-neutral-600">
            <button
              type="button"
              onClick={() => onNavigate('HOME')}
              className={`px-3 py-2 rounded-lg transition-colors cursor-pointer ${
                activeTab === 'HOME' ? 'text-emerald-800 bg-emerald-50' : 'hover:text-emerald-700 hover:bg-neutral-50'
              }`}
            >
              Overview
            </button>
            <button
              type="button"
              onClick={() => onNavigate('VOTE')}
              className={`px-3 py-2 rounded-lg transition-colors cursor-pointer ${
                activeTab === 'VOTE' ? 'text-emerald-800 bg-emerald-50' : 'hover:text-emerald-700 hover:bg-neutral-50'
              }`}
            >
              Voting Chamber
            </button>
            <button
              type="button"
              onClick={() => onNavigate('RESULTS')}
              className={`px-3 py-2 rounded-lg transition-colors cursor-pointer ${
                activeTab === 'RESULTS' ? 'text-emerald-800 bg-emerald-50' : 'hover:text-emerald-700 hover:bg-neutral-50'
              }`}
            >
              Live Results
            </button>
            <button
              type="button"
              onClick={() => onNavigate('AUDIT')}
              className={`px-3 py-2 rounded-lg transition-colors cursor-pointer ${
                activeTab === 'AUDIT' ? 'text-emerald-800 bg-emerald-50' : 'hover:text-emerald-700 hover:bg-neutral-50'
              }`}
            >
              Audit Ledger
            </button>
          </nav>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Reset Demo State Button */}
          <button
            type="button"
            onClick={onResetDemo}
            title="Reset elections, vote counters, and demo sessions"
            className="p-2 rounded-xl text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition-colors text-xs font-semibold flex items-center gap-1 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span className="hidden lg:inline text-[11px]">Reset Demo</span>
          </button>

          {currentVoter ? (
            <div className="flex items-center gap-2">
              {/* Voter badge */}
              <button
                type="button"
                onClick={onOpenVoterCard}
                className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100/70 border border-emerald-200 text-left transition-all cursor-pointer"
              >
                <img
                  src={currentVoter.facePhotoUrl || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400"}
                  alt={currentVoter.name}
                  className="w-7 h-7 rounded-lg object-cover border border-emerald-500/40 shrink-0"
                />
                <div className="hidden sm:block">
                  <div className="text-xs font-bold text-emerald-950 leading-tight truncate max-w-[120px]">
                    {currentVoter.name}
                  </div>
                  <div className="text-[10px] font-mono text-emerald-700">
                    {currentVoter.id}
                  </div>
                </div>
                <IdCard className="w-4 h-4 text-emerald-700 shrink-0" />
              </button>

              {/* Logout button */}
              <button
                type="button"
                onClick={onLogout}
                title="Sign out of voter session"
                className="p-2 rounded-xl text-neutral-400 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onOpenLogin}
                className="py-2 px-3.5 rounded-xl border border-neutral-300 hover:bg-neutral-50 text-neutral-700 text-xs font-bold transition-all cursor-pointer"
              >
                Voter Login
              </button>
              <button
                type="button"
                onClick={onOpenRegister}
                className="py-2 px-3.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                Register
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Mobile nav subbar */}
      <div className="md:hidden flex items-center justify-around border-t border-neutral-200/60 py-2 bg-neutral-50/70 text-xs font-bold text-neutral-600 px-2">
        <button
          type="button"
          onClick={() => onNavigate('HOME')}
          className={`px-2 py-1 rounded-md ${activeTab === 'HOME' ? 'text-emerald-800 bg-emerald-100/60' : ''}`}
        >
          Overview
        </button>
        <button
          type="button"
          onClick={() => onNavigate('VOTE')}
          className={`px-2 py-1 rounded-md ${activeTab === 'VOTE' ? 'text-emerald-800 bg-emerald-100/60' : ''}`}
        >
          Voting Chamber
        </button>
        <button
          type="button"
          onClick={() => onNavigate('RESULTS')}
          className={`px-2 py-1 rounded-md ${activeTab === 'RESULTS' ? 'text-emerald-800 bg-emerald-100/60' : ''}`}
        >
          Live Results
        </button>
        <button
          type="button"
          onClick={() => onNavigate('AUDIT')}
          className={`px-2 py-1 rounded-md ${activeTab === 'AUDIT' ? 'text-emerald-800 bg-emerald-100/60' : ''}`}
        >
          Audit Ledger
        </button>
      </div>
    </header>
  );
};
