import React, { useEffect } from 'react';
import { CheckCircle2, ShieldCheck, Printer, Download, Share2, BarChart3, RotateCcw, ExternalLink } from 'lucide-react';
import confetti from 'canvas-confetti';
import { VoteReceipt } from '../types';

interface VotingReceiptProps {
  receipt: VoteReceipt;
  onViewResults: () => void;
  onRestart: () => void;
}

export const VotingReceipt: React.FC<VotingReceiptProps> = ({
  receipt,
  onViewResults,
  onRestart
}) => {
  useEffect(() => {
    // Launch celebratory confetti burst
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#176b4d', '#b78628', '#10b981', '#3b82f6']
      });
    } catch {
      // ignore
    }
  }, []);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl border border-neutral-200/80 overflow-hidden max-w-2xl mx-auto">
      {/* Official Certificate Banner */}
      <div className="bg-emerald-950 text-white p-6 sm:p-8 text-center relative overflow-hidden border-b border-emerald-900/40">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:16px_16px]"></div>

        <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-400/40 flex items-center justify-center text-emerald-400 mx-auto mb-3 shadow-lg">
          <CheckCircle2 className="w-9 h-9" />
        </div>

        <span className="text-[11px] font-mono tracking-widest text-emerald-400 uppercase bg-emerald-900/60 px-3 py-1 rounded-full border border-emerald-700/60 inline-block mb-2">
          OFFICIAL ELECTORAL RECEIPT • VERIFIED
        </span>

        <h3 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-white">
          Ballot Successfully Sealed & Recorded
        </h3>

        <p className="text-xs sm:text-sm text-emerald-200/80 max-w-md mx-auto mt-1.5 font-medium">
          Your democratic choice has been securely cast and permanently appended to the tamper-evident electoral ledger.
        </p>
      </div>

      <div className="p-6 sm:p-8 space-y-6">
        {/* Certificate Card */}
        <div className="bg-neutral-50/80 rounded-2xl p-6 border-2 border-dashed border-emerald-300 relative space-y-4">
          <div className="flex items-center justify-between border-b border-neutral-200/80 pb-3">
            <div>
              <div className="text-[11px] text-neutral-400 font-mono">RECEIPT REFERENCE</div>
              <div className="font-mono font-bold text-base text-neutral-900">{receipt.receiptId}</div>
            </div>
            <div className="text-right">
              <div className="text-[11px] text-neutral-400 font-mono">TIMESTAMP</div>
              <div className="text-xs font-semibold text-neutral-800">{receipt.timestamp}</div>
            </div>
          </div>

          {/* Key fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <span className="text-neutral-500 block">Voter Name</span>
              <strong className="text-neutral-900 text-sm font-semibold">{receipt.voterName}</strong>
            </div>

            <div>
              <span className="text-neutral-500 block">Voter ID</span>
              <strong className="text-neutral-900 text-sm font-mono">{receipt.voterId}</strong>
            </div>

            <div>
              <span className="text-neutral-500 block">Election</span>
              <strong className="text-neutral-900 text-sm font-semibold">{receipt.electionTitle}</strong>
            </div>

            <div>
              <span className="text-neutral-500 block">Ballot Choice</span>
              <strong className="text-emerald-800 text-sm font-bold bg-emerald-100/60 px-2 py-0.5 rounded inline-block">
                {receipt.candidateName} — {receipt.partyName}
              </strong>
            </div>
          </div>

          {/* Cryptographic hash */}
          <div className="p-3.5 bg-neutral-900 rounded-xl text-white space-y-1 font-mono text-[11px]">
            <div className="flex items-center justify-between text-neutral-400 text-[10px]">
              <span>BALLOT CRYPTOGRAPHIC HASH (SHA-256)</span>
              <span className="text-emerald-400 font-sans font-bold">TAMPER-EVIDENT</span>
            </div>
            <div className="text-emerald-300 font-bold break-all tracking-wider">
              {receipt.ballotHash}
            </div>
            <div className="text-[10px] text-neutral-400 truncate">
              Digital Signature: {receipt.digitalSignature}
            </div>
          </div>

          {/* Verification Badges */}
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-semibold border border-emerald-200">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
              Biometric Liveness Match: {receipt.verificationMethods.faceConfidenceScore}%
            </span>

            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-semibold border border-emerald-200">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
              Mobile OTP Verified (2FA)
            </span>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <button
            type="button"
            onClick={onViewResults}
            className="w-full sm:flex-1 py-3.5 px-5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs sm:text-sm tracking-wide shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <BarChart3 className="w-4 h-4" />
            View Live Election Results
          </button>

          <button
            type="button"
            onClick={handlePrint}
            className="w-full sm:w-auto py-3.5 px-5 rounded-xl border border-neutral-300 hover:bg-neutral-50 text-neutral-700 font-semibold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print Receipt
          </button>

          <button
            type="button"
            onClick={onRestart}
            className="w-full sm:w-auto py-3.5 px-4 rounded-xl border border-neutral-200 hover:bg-neutral-50 text-neutral-600 font-medium text-xs sm:text-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            Demo Home
          </button>
        </div>
      </div>
    </div>
  );
};
