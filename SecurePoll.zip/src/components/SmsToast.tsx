import React, { useEffect, useState } from 'react';
import { MessageSquare, Copy, Check, X, ShieldAlert, Sparkles } from 'lucide-react';
import { playOtpArrivalSound } from '../services/audio';

interface SmsToastProps {
  code: string;
  phone: string;
  onAutofill: (code: string) => void;
  onClose: () => void;
}

export const SmsToast: React.FC<SmsToastProps> = ({
  code,
  phone,
  onAutofill,
  onClose
}) => {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    playOtpArrivalSound();
  }, [code]);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed top-5 right-5 z-50 max-w-sm w-full animate-in slide-in-from-top-6 duration-300">
      <div className="bg-neutral-900 text-white rounded-2xl p-4 shadow-2xl border border-neutral-700/80 backdrop-blur-md">
        {/* Phone / Carrier header */}
        <div className="flex items-center justify-between border-b border-neutral-800 pb-2 mb-2.5">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <MessageSquare className="w-3.5 h-3.5" />
            </div>
            <span className="text-xs font-semibold tracking-wide text-neutral-300">MESSAGES • NOW</span>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white transition-colors p-1"
            title="Dismiss notification"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* SMS Content */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-mono text-emerald-400">
            <span>FROM: GOV-SECUREPOLL</span>
            <span>TO: {phone}</span>
          </div>
          <p className="text-sm text-neutral-100 font-sans leading-snug">
            Your confidential electoral OTP is <span className="font-mono font-bold text-lg text-emerald-300 tracking-wider bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-700/50">{code}</span>. Valid for 60 seconds. Do not disclose.
          </p>
        </div>

        {/* Fast Action Buttons */}
        <div className="mt-3 pt-2.5 border-t border-neutral-800 flex items-center gap-2">
          <button
            type="button"
            onClick={() => onAutofill(code)}
            className="flex-1 py-1.5 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5" />
            1-Click Auto-Fill
          </button>
          <button
            type="button"
            onClick={handleCopy}
            className="py-1.5 px-3 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium transition-all flex items-center gap-1"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'Copied' : 'Copy'}
          </button>
        </div>
      </div>
    </div>
  );
};
