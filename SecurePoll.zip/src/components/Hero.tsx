import React from 'react';
import { ShieldCheck, Scan, Smartphone, Lock, ArrowRight, Sparkles, CheckCircle2, UserCheck } from 'lucide-react';
import { Voter } from '../types';

interface HeroProps {
  currentVoter: Voter | null;
  onStartVoting: () => void;
  onOpenRegister: () => void;
  onOpenHowItWorks: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  currentVoter,
  onStartVoting,
  onOpenRegister,
  onOpenHowItWorks
}) => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-white via-emerald-50/40 to-neutral-50 py-16 sm:py-24 border-b border-neutral-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Text Column */}
          <div className="lg:col-span-7 space-y-6 text-left">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/10 border border-amber-600/20 text-amber-900 text-xs font-extrabold tracking-wider uppercase font-mono">
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
              Electoral Security Architecture • ISO/IEC 30107
            </div>

            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-emerald-950 leading-[1.08]">
              Online Voting System with Face Recognition & OTP
            </h1>

            <p className="text-base sm:text-lg text-neutral-600 max-w-2xl leading-relaxed">
              SecurePoll delivers an institutional-grade digital ballot chamber. Combines multi-factor voter registration, live camera facial liveness analysis, encrypted mobile SMS OTP verification, and tamper-evident cryptographic voting receipts.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-3.5 pt-2">
              <button
                type="button"
                onClick={onStartVoting}
                className="py-4 px-7 rounded-2xl bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white font-bold text-sm tracking-wide shadow-xl shadow-emerald-950/15 flex items-center gap-2.5 transition-all hover:-translate-y-0.5 cursor-pointer"
              >
                <span>{currentVoter ? 'Enter Voting Chamber' : 'Start Voting Session'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              {!currentVoter && (
                <button
                  type="button"
                  onClick={onOpenRegister}
                  className="py-4 px-6 rounded-2xl bg-white hover:bg-neutral-50 text-neutral-800 font-bold text-sm border border-neutral-300 shadow-xs flex items-center gap-2 transition-all hover:-translate-y-0.5 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-emerald-700" />
                  <span>Register Voter Account</span>
                </button>
              )}

              <button
                type="button"
                onClick={onOpenHowItWorks}
                className="py-4 px-4 text-emerald-800 hover:text-emerald-950 font-bold text-sm flex items-center gap-1 transition-colors cursor-pointer"
              >
                Verification Flow ↓
              </button>
            </div>

            {/* Hero Stats */}
            <div className="grid grid-cols-3 gap-6 pt-6 border-t border-neutral-200/80 max-w-lg">
              <div>
                <dt className="text-2xl sm:text-3xl font-display font-bold text-emerald-900">2-Factor</dt>
                <dd className="text-xs text-neutral-500 font-medium mt-0.5">Face + SMS Biometrics</dd>
              </div>

              <div>
                <dt className="text-2xl sm:text-3xl font-display font-bold text-emerald-900">60s</dt>
                <dd className="text-xs text-neutral-500 font-medium mt-0.5">Secure OTP Expiry</dd>
              </div>

              <div>
                <dt className="text-2xl sm:text-3xl font-display font-bold text-emerald-900">1 Vote</dt>
                <dd className="text-xs text-neutral-500 font-medium mt-0.5">Strict Single Ballot Limit</dd>
              </div>
            </div>
          </div>

          {/* Right Visual Interactive Card */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative w-full max-w-sm">
              {/* Decorative Glow */}
              <div className="absolute -inset-1 bg-gradient-to-r from-emerald-600 to-amber-500 rounded-3xl blur-xl opacity-20 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>

              {/* Main Card */}
              <div className="relative bg-white rounded-3xl p-5 shadow-2xl border border-neutral-200/80 space-y-4">
                {/* Scanner Frame */}
                <div className="relative aspect-4/3 bg-emerald-950 rounded-2xl overflow-hidden flex items-center justify-center border border-emerald-900">
                  <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:12px_12px]"></div>

                  {/* 4 Corner reticles */}
                  <div className="absolute top-3 left-3 w-5 h-5 border-t-2 border-l-2 border-emerald-400"></div>
                  <div className="absolute top-3 right-3 w-5 h-5 border-t-2 border-r-2 border-emerald-400"></div>
                  <div className="absolute bottom-3 left-3 w-5 h-5 border-b-2 border-l-2 border-emerald-400"></div>
                  <div className="absolute bottom-3 right-3 w-5 h-5 border-b-2 border-r-2 border-emerald-400"></div>

                  {/* Scanning line animation */}
                  <div className="absolute left-4 right-4 h-0.5 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_10px_#34d399] animate-scan-laser"></div>

                  {/* Face glyph SVG */}
                  <svg viewBox="0 0 100 100" className="w-32 h-32 text-emerald-400/70">
                    <circle cx="50" cy="38" r="20" fill="none" stroke="currentColor" strokeWidth="2.5" />
                    <path d="M18 92 C18 68 32 58 50 58 C68 58 82 68 82 92" fill="none" stroke="currentColor" strokeWidth="2.5" />
                  </svg>

                  {/* Top tag */}
                  <div className="absolute top-3 left-1/2 -translate-x-1/2 bg-emerald-900/80 border border-emerald-700/60 px-3 py-0.5 rounded-full text-[10px] font-mono text-emerald-300">
                    BIOMETRIC SCANNING
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-neutral-900">Optical Liveness Analysis</span>
                  <span className="text-emerald-700 font-mono font-bold">98.4% Confidence</span>
                </div>

                {/* Floating Chips */}
                <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200/80 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center font-bold text-xs">
                      OTP
                    </div>
                    <span className="text-xs text-neutral-600 font-medium">Encrypted SMS 2FA</span>
                  </div>
                  <span className="font-mono font-bold text-emerald-700 tracking-widest text-sm bg-emerald-100/60 px-2 py-0.5 rounded">
                    • • • • • •
                  </span>
                </div>

                <div className="p-3 bg-emerald-50/70 rounded-xl border border-emerald-200/80 flex items-center gap-2.5 text-xs text-emerald-900">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Sha-256 Tamper-Proof Cryptographic Ballot Seals</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
