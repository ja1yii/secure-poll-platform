import React from 'react';
import { ShieldCheck, Lock, CheckCircle2, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-emerald-950 text-neutral-300 py-12 border-t border-emerald-900/40 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2.5">
              <span className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-sm">
                ✓
              </span>
              <span className="font-display font-bold text-xl text-white">
                SecurePoll
              </span>
            </div>
            <p className="text-neutral-400 text-xs max-w-sm leading-relaxed">
              Institutional electronic voting and identity verification system. Implements ISO/IEC 30107-3 facial liveness analysis, multi-channel 2FA, and cryptographic vote auditing.
            </p>
          </div>

          {/* Verification Standards */}
          <div className="space-y-2">
            <span className="font-bold text-white text-xs uppercase tracking-wider block font-mono">
              SECURITY PROTOCOLS
            </span>
            <ul className="space-y-1.5 text-neutral-400 text-xs">
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Webcam Liveness &amp; Depth Checks</span>
              </li>
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Encrypted 60s SMS OTP (2FA)</span>
              </li>
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Zero-Knowledge Secret Ballot</span>
              </li>
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>SHA-256 Tamper-Proof Receipts</span>
              </li>
            </ul>
          </div>

          {/* Legal / Civic Notice */}
          <div className="space-y-2">
            <span className="font-bold text-white text-xs uppercase tracking-wider block font-mono">
              CIVIC COMPLIANCE
            </span>
            <p className="text-neutral-400 text-xs leading-relaxed">
              Demonstration &amp; prototype environment for democratic ballot automation. Adheres to electoral secret ballot transparency guidelines.
            </p>
          </div>
        </div>

        <div className="pt-8 border-t border-emerald-900/60 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-neutral-500">
          <div>
            &copy; {new Date().getFullYear()} SecurePoll System. All rights reserved.
          </div>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <Lock className="w-3 h-3 text-emerald-500" />
              256-Bit SSL Encrypted
            </span>
            <span>Electoral Security Grade</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
