import React from 'react';
import { BarChart3, TrendingUp, Users, CheckCircle2, Award, ShieldAlert, Clock } from 'lucide-react';
import { Candidate, Election } from '../types';

interface ElectionResultsProps {
  election: Election;
  results: Record<string, number>;
  onVoteClick?: () => void;
}

export const ElectionResults: React.FC<ElectionResultsProps> = ({
  election,
  results,
  onVoteClick
}) => {
  // Calculate total votes
  const totalVotes = Object.values(results).reduce((sum, count) => sum + count, 0);

  // Sort candidates by votes descending
  const sortedCandidates = [...election.candidates].sort((a, b) => {
    const votesA = results[a.id] || 0;
    const votesB = results[b.id] || 0;
    return votesB - votesA;
  });

  const leadingCandidate = sortedCandidates[0];
  const leadingVotes = results[leadingCandidate?.id] || 0;
  const runnerUp = sortedCandidates[1];
  const runnerUpVotes = results[runnerUp?.id] || 0;
  const leadMargin = leadingVotes - runnerUpVotes;

  const turnoutPercentage = ((totalVotes / election.totalRegisteredVoters) * 100).toFixed(1);

  return (
    <div className="bg-white rounded-3xl shadow-xl border border-neutral-200/80 overflow-hidden max-w-4xl mx-auto">
      {/* Header */}
      <div className="bg-emerald-950 text-white p-6 sm:p-8 border-b border-emerald-900/40">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="text-xs font-mono font-semibold tracking-wider text-emerald-400 uppercase">
                LIVE VERIFIED TALLY • OFFICIAL FEED
              </span>
            </div>
            <h3 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-white">
              {election.title}
            </h3>
            <p className="text-xs sm:text-sm text-emerald-300/80 mt-1">
              {election.description}
            </p>
          </div>

          {onVoteClick && (
            <button
              type="button"
              onClick={onVoteClick}
              className="py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md self-start sm:self-auto cursor-pointer"
            >
              Cast Your Vote →
            </button>
          )}
        </div>

        {/* Aggregate Stats Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-emerald-900/60 text-xs">
          <div className="bg-emerald-900/50 p-3 rounded-xl border border-emerald-800/60">
            <span className="text-emerald-300/80 block text-[11px]">Total Ballots Cast</span>
            <strong className="text-xl font-bold font-mono text-white mt-0.5 block">
              {totalVotes.toLocaleString()}
            </strong>
          </div>

          <div className="bg-emerald-900/50 p-3 rounded-xl border border-emerald-800/60">
            <span className="text-emerald-300/80 block text-[11px]">Voter Turnout</span>
            <strong className="text-xl font-bold font-mono text-emerald-400 mt-0.5 block">
              {turnoutPercentage}%
            </strong>
          </div>

          <div className="bg-emerald-900/50 p-3 rounded-xl border border-emerald-800/60">
            <span className="text-emerald-300/80 block text-[11px]">Registered Voters</span>
            <strong className="text-xl font-bold font-mono text-white mt-0.5 block">
              {election.totalRegisteredVoters.toLocaleString()}
            </strong>
          </div>

          <div className="bg-emerald-900/50 p-3 rounded-xl border border-emerald-800/60">
            <span className="text-emerald-300/80 block text-[11px]">Current Plurality</span>
            <strong className="text-sm font-bold text-white mt-1 block truncate">
              {leadingCandidate ? leadingCandidate.name : '—'}
            </strong>
          </div>
        </div>
      </div>

      {/* Main Results Body */}
      <div className="p-6 sm:p-8 space-y-6">
        {/* Leading Candidate Spotlight Card */}
        {leadingCandidate && (
          <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-50 via-neutral-50 to-emerald-50 border border-emerald-200/90 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="relative shrink-0">
                <img
                  src={leadingCandidate.photoUrl}
                  alt={leadingCandidate.name}
                  className="w-16 h-16 rounded-xl object-cover border-2 border-emerald-600 shadow-sm"
                />
                <span className="absolute -top-2 -left-2 bg-amber-500 text-white rounded-full p-1 shadow-md">
                  <Award className="w-4 h-4" />
                </span>
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold text-emerald-800 tracking-wider uppercase bg-emerald-100 px-2 py-0.5 rounded-full">
                    PROJECTED LEADER
                  </span>
                  <span className="text-xs text-neutral-500 font-medium">
                    +{leadMargin} votes lead
                  </span>
                </div>
                <h4 className="text-lg font-bold text-neutral-900 mt-0.5">{leadingCandidate.name}</h4>
                <p className="text-xs text-neutral-600">{leadingCandidate.party}</p>
              </div>
            </div>

            <div className="text-left sm:text-right">
              <div className="text-2xl font-mono font-bold text-emerald-900">
                {leadingVotes.toLocaleString()} <span className="text-sm font-sans font-normal text-neutral-600">votes</span>
              </div>
              <div className="text-xs font-semibold text-emerald-700">
                {totalVotes > 0 ? ((leadingVotes / totalVotes) * 100).toFixed(1) : 0}% of total ballots
              </div>
            </div>
          </div>
        )}

        {/* Candidate Breakdown List */}
        <div className="space-y-4">
          <h4 className="text-sm font-bold text-neutral-900 uppercase tracking-wider text-neutral-500">
            Full Candidate Vote Distribution
          </h4>

          <div className="space-y-3">
            {sortedCandidates.map((candidate, index) => {
              const votes = results[candidate.id] || 0;
              const percentage = totalVotes > 0 ? ((votes / totalVotes) * 100).toFixed(1) : '0.0';

              return (
                <div
                  key={candidate.id}
                  className="p-4 rounded-xl bg-neutral-50/70 border border-neutral-200/80 space-y-2.5 transition-all hover:bg-neutral-50"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="w-6 text-center font-mono font-bold text-sm text-neutral-400">
                        #{index + 1}
                      </span>
                      <img
                        src={candidate.photoUrl}
                        alt={candidate.name}
                        className="w-10 h-10 rounded-lg object-cover border border-neutral-200 shrink-0"
                      />
                      <div>
                        <div className="text-sm font-bold text-neutral-900 flex items-center gap-2">
                          <span>{candidate.name}</span>
                          <span
                            className="text-[10px] font-semibold px-2 py-0.2 rounded-full text-white"
                            style={{ backgroundColor: candidate.partyColor }}
                          >
                            {candidate.party}
                          </span>
                        </div>
                        <div className="text-xs text-neutral-500 font-mono">
                          Symbol: {candidate.symbol}
                        </div>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-sm font-bold font-mono text-neutral-900">
                        {votes.toLocaleString()}
                      </div>
                      <div className="text-xs font-semibold text-neutral-500">
                        {percentage}%
                      </div>
                    </div>
                  </div>

                  {/* Progress bar */}
                  <div className="w-full h-3 bg-neutral-200/80 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-700 ease-out"
                      style={{
                        width: `${percentage}%`,
                        backgroundColor: candidate.partyColor || '#176b4d'
                      }}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
