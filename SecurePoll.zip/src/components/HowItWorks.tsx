import React from 'react';
import { UserCheck, Scan, KeyRound, Vote, FileCheck, Shield, CheckCircle2 } from 'lucide-react';

export const HowItWorks: React.FC = () => {
  const steps = [
    {
      step: '01',
      icon: UserCheck,
      title: 'Voter Authentication',
      desc: 'Enter your certified Voter ID number and account password to retrieve your registered electoral record.'
    },
    {
      step: '02',
      icon: Scan,
      title: 'Face Liveness Scan',
      desc: 'Live webcam analyzes facial geometry, micro-movement, and optical depth, matching against your enrolled photo.'
    },
    {
      step: '03',
      icon: KeyRound,
      title: 'Encrypted SMS OTP',
      desc: 'A random 6-digit one-time authorization code is dispatched to your registered phone with a 60-second validity window.'
    },
    {
      step: '04',
      icon: Vote,
      title: 'Secret Ballot Cast',
      desc: 'Review candidates and policy agendas. Select your choice in total privacy with one-voter-one-vote enforcement.'
    },
    {
      step: '05',
      icon: FileCheck,
      title: 'Cryptographic Receipt',
      desc: 'An immutable SHA-256 ballot seal is issued. The anonymous vote updates the live tally and public audit ledger.'
    }
  ];

  return (
    <section id="how-it-works" className="py-20 bg-white border-b border-neutral-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold tracking-wide uppercase font-mono">
            <Shield className="w-3.5 h-3.5 text-emerald-600" />
            End-To-End Verifiable Architecture
          </div>
          <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-neutral-900">
            5-Stage Democratic Verification Pipeline
          </h2>
          <p className="text-neutral-600 text-sm sm:text-base leading-relaxed">
            Engineered to prevent identity spoofing, duplicate balloting, and ballot interception while safeguarding absolute voter secrecy.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6">
          {steps.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="relative bg-neutral-50/70 rounded-2xl p-6 border border-neutral-200/80 hover:border-emerald-300 hover:bg-emerald-50/20 transition-all hover:-translate-y-1 group"
              >
                {/* Step pill */}
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 rounded-xl bg-emerald-100/80 text-emerald-800 flex items-center justify-center font-mono font-bold text-sm border border-emerald-200/60 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                    {item.step}
                  </div>
                  <Icon className="w-5 h-5 text-neutral-400 group-hover:text-emerald-600 transition-colors" />
                </div>

                <h3 className="text-base font-bold text-neutral-900 mb-2">
                  {item.title}
                </h3>

                <p className="text-xs text-neutral-600 leading-relaxed">
                  {item.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
