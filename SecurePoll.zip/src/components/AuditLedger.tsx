import React, { useState } from 'react';
import { ShieldCheck, Search, FileCheck, CheckCircle2, Lock, ExternalLink } from 'lucide-react';
import { AuditRecord } from '../types';

interface AuditLedgerProps {
  auditLogs: AuditRecord[];
}

export const AuditLedger: React.FC<AuditLedgerProps> = ({ auditLogs }) => {
  const [searchTerm, setSearchTerm] = useState<string>('');

  const filteredLogs = auditLogs.filter(log =>
    log.receiptId.toLowerCase().includes(searchTerm.toLowerCase()) ||
    log.ballotHashMasked.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-white rounded-3xl shadow-xl border border-neutral-200/80 overflow-hidden max-w-4xl mx-auto">
      {/* Header */}
      <div className="bg-emerald-950 text-white p-6 sm:p-8 border-b border-emerald-900/40">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-mono font-semibold tracking-wider text-emerald-400 uppercase">
                PUBLIC ELECTORAL INTEGRITY LEDGER
              </span>
            </div>
            <h3 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-white">
              Tamper-Evident Vote Audit Trail
            </h3>
            <p className="text-xs sm:text-sm text-emerald-300/80 mt-1">
              Verify your ballot receipt on the public ledger. Individual candidate selections remain secret as guaranteed by constitutional ballot law.
            </p>
          </div>

          <div className="bg-emerald-900/60 border border-emerald-700/60 px-4 py-2 rounded-2xl text-center self-start sm:self-auto font-mono text-xs">
            <span className="text-emerald-400 block text-[10px]">CONSENSUS STATUS</span>
            <span className="font-bold text-white text-sm">100% AUDITED</span>
          </div>
        </div>

        {/* Search Filter */}
        <div className="mt-6 relative">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Search by Receipt ID (e.g. REC-2026-...) or Ballot Hash..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-neutral-900/90 text-white border border-emerald-800/60 placeholder:text-neutral-500 text-xs sm:text-sm outline-none focus:border-emerald-400 font-mono"
          />
        </div>
      </div>

      {/* Ledger Table */}
      <div className="p-6 sm:p-8 overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="border-b border-neutral-200 text-neutral-400 font-mono text-[11px] uppercase tracking-wider">
              <th className="pb-3 font-semibold">Receipt Ref</th>
              <th className="pb-3 font-semibold">Cryptographic Hash Mask</th>
              <th className="pb-3 font-semibold">Verification Proof</th>
              <th className="pb-3 font-semibold">Timestamp</th>
              <th className="pb-3 font-semibold text-right">Integrity</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-100">
            {filteredLogs.map((log) => (
              <tr key={log.id} className="hover:bg-neutral-50/70 transition-colors">
                <td className="py-3.5 font-mono font-bold text-neutral-900">
                  {log.receiptId}
                </td>
                <td className="py-3.5 font-mono text-emerald-800 font-medium">
                  {log.ballotHashMasked}
                </td>
                <td className="py-3.5">
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 text-[11px] font-semibold border border-emerald-200">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    {log.verificationBadge}
                  </span>
                </td>
                <td className="py-3.5 text-neutral-500 font-mono text-[11px]">
                  {log.timestamp}
                </td>
                <td className="py-3.5 text-right">
                  <span className="inline-flex items-center gap-1 text-emerald-700 font-bold font-mono text-[11px]">
                    <Lock className="w-3 h-3" />
                    SEALED
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {filteredLogs.length === 0 && (
          <div className="text-center py-10 text-neutral-500 text-xs">
            No audit records found matching &ldquo;{searchTerm}&rdquo;.
          </div>
        )}
      </div>
    </div>
  );
};
