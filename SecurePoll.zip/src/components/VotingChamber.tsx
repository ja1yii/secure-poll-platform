import React, { useState, useEffect } from 'react';
import { User, Scan, KeyRound, Vote, FileCheck, ShieldCheck, CheckCircle2, AlertCircle, ArrowRight, RotateCcw, IdCard, Lock } from 'lucide-react';
import { Voter, Election, VoteReceipt, VotingStep } from '../types';
import { getCurrentVoter, castBallotRecord, getStoredReceipts } from '../services/storage';
import { FaceVerification } from './FaceVerification';
import { OtpVerification } from './OtpVerification';
import { BallotChamber } from './BallotChamber';
import { VotingReceipt } from './VotingReceipt';
import { playSuccessChime } from '../services/audio';

interface VotingChamberProps {
  election: Election;
  currentVoter: Voter | null;
  onOpenAuthModal: (tab: 'LOGIN' | 'REGISTER') => void;
  onOpenVoterCard: () => void;
  onVoteCompleted: () => void;
  onNavigateToResults: () => void;
}

export const VotingChamber: React.FC<VotingChamberProps> = ({
  election,
  currentVoter,
  onOpenAuthModal,
  onOpenVoterCard,
  onVoteCompleted,
  onNavigateToResults
}) => {
  const [currentStep, setCurrentStep] = useState<VotingStep>('LOGIN');
  const [faceConfidence, setFaceConfidence] = useState<number>(97.5);
  const [capturedFaceUrl, setCapturedFaceUrl] = useState<string>('');
  const [activeReceipt, setActiveReceipt] = useState<VoteReceipt | null>(null);
  const [alreadyVotedReceipt, setAlreadyVotedReceipt] = useState<VoteReceipt | null>(null);

  // Check if current voter has already voted in this election
  useEffect(() => {
    if (currentVoter) {
      const receipts = getStoredReceipts();
      const existing = receipts.find(
        r => r.voterId === currentVoter.id && r.electionId === election.id
      );

      if (existing || currentVoter.hasVoted) {
        setAlreadyVotedReceipt(existing || null);
      } else {
        setAlreadyVotedReceipt(null);
        // Automatically start at Face Scan if already logged in!
        if (currentStep === 'LOGIN') {
          setCurrentStep('FACE_SCAN');
        }
      }
    } else {
      setCurrentStep('LOGIN');
      setAlreadyVotedReceipt(null);
    }
  }, [currentVoter, election.id]);

  // Handle Face Scan success
  const handleFaceVerified = (confidenceScore: number, snapshotUrl: string) => {
    setFaceConfidence(confidenceScore);
    setCapturedFaceUrl(snapshotUrl);
    setCurrentStep('OTP');
  };

  // Handle OTP success
  const handleOtpVerified = () => {
    setCurrentStep('BALLOT');
  };

  // Handle Ballot Vote cast
  const handleVoteCast = (candidateId: string) => {
    if (!currentVoter) return;

    const result = castBallotRecord({
      electionId: election.id,
      candidateId,
      voter: currentVoter,
      faceConfidenceScore: faceConfidence
    });

    if (result.success && result.receipt) {
      setActiveReceipt(result.receipt);
      setCurrentStep('RECEIPT');
      onVoteCompleted();
    }
  };

  // Steps definition for top navigation indicator
  const stepsList: { key: VotingStep; label: string; num: number }[] = [
    { key: 'LOGIN', label: 'Voter Auth', num: 1 },
    { key: 'FACE_SCAN', label: 'Face Scan', num: 2 },
    { key: 'OTP', label: 'SMS OTP', num: 3 },
    { key: 'BALLOT', label: 'Cast Ballot', num: 4 },
    { key: 'RECEIPT', label: 'Vote Result', num: 5 }
  ];

  const getStepIndex = (step: VotingStep) => {
    switch (step) {
      case 'LOGIN': return 1;
      case 'FACE_SCAN': return 2;
      case 'OTP': return 3;
      case 'BALLOT': return 4;
      case 'RECEIPT': return 5;
    }
  };

  const activeIndex = getStepIndex(currentStep);

  return (
    <section id="demo" className="py-12 sm:py-20 bg-neutral-100/60 border-b border-neutral-200/80">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Title */}
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100/80 border border-emerald-300 text-emerald-800 text-xs font-bold font-mono tracking-wider uppercase">
            <Lock className="w-3.5 h-3.5 text-emerald-700" />
            Official Balloting Chamber
          </div>
          <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-neutral-900">
            Secure Voting Process
          </h2>
          <p className="text-xs sm:text-sm text-neutral-600">
            Follow the 5-step authentication pipeline. Once authenticated via biometric liveness and OTP, your secret ballot will be unlocked.
          </p>
        </div>

        {/* Multi-step Progress Bar */}
        <div className="bg-white rounded-2xl shadow-sm border border-neutral-200/90 overflow-hidden">
          <div className="grid grid-cols-5 divide-x divide-neutral-200 text-center font-bold text-xs">
            {stepsList.map((s) => {
              const isActive = currentStep === s.key;
              const isPassed = activeIndex > s.num;

              return (
                <div
                  key={s.key}
                  className={`py-3.5 px-1 sm:px-3 flex flex-col sm:flex-row items-center justify-center gap-1.5 transition-all ${
                    isActive
                      ? 'bg-emerald-50/80 text-emerald-900 border-b-3 border-emerald-600 font-extrabold'
                      : isPassed
                      ? 'text-emerald-700 bg-neutral-50/50'
                      : 'text-neutral-400 bg-white'
                  }`}
                >
                  <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-mono shrink-0 ${
                    isActive
                      ? 'bg-emerald-600 text-white'
                      : isPassed
                      ? 'bg-emerald-200 text-emerald-800'
                      : 'bg-neutral-200 text-neutral-500'
                  }`}>
                    {isPassed ? '✓' : s.num}
                  </span>
                  <span className="truncate text-[11px] sm:text-xs">{s.label}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* ALREADY VOTED NOTICE (If voter already cast their ballot) */}
        {alreadyVotedReceipt && (
          <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border border-amber-300/80 text-center max-w-xl mx-auto space-y-4">
            <div className="w-14 h-14 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center mx-auto shadow-sm">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <h3 className="font-display text-2xl font-bold text-neutral-900">
                You Have Already Voted
              </h3>
              <p className="text-xs text-neutral-600 max-w-md mx-auto">
                Electoral records confirm your ballot has already been cast and cryptographically sealed for this election. Multiple voting is strictly prohibited by electoral law.
              </p>
            </div>

            <div className="p-4 bg-neutral-50 rounded-2xl border border-neutral-200 text-xs text-left space-y-1.5 font-mono">
              <div className="flex justify-between">
                <span className="text-neutral-500">Voter:</span>
                <span className="font-bold text-neutral-900">{currentVoter?.name} ({currentVoter?.id})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Receipt Ref:</span>
                <span className="font-bold text-emerald-800">{alreadyVotedReceipt.receiptId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Timestamp:</span>
                <span className="text-neutral-700">{alreadyVotedReceipt.timestamp}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Verification:</span>
                <span className="text-emerald-700 font-bold">Face Liveness + SMS OTP</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button
                type="button"
                onClick={onNavigateToResults}
                className="flex-1 py-3 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-all shadow-md cursor-pointer"
              >
                View Live Election Tally
              </button>
              <button
                type="button"
                onClick={() => onOpenAuthModal('LOGIN')}
                className="py-3 px-4 rounded-xl border border-neutral-300 text-neutral-700 text-xs font-semibold hover:bg-neutral-50 transition-all cursor-pointer"
              >
                Login as Another Voter
              </button>
            </div>
          </div>
        )}

        {/* STAGE VIEWS */}
        {!alreadyVotedReceipt && (
          <div>
            {/* STEP 1: VOTER AUTH */}
            {currentStep === 'LOGIN' && (
              <div className="bg-white rounded-3xl p-6 sm:p-10 shadow-xl border border-neutral-200/80 max-w-xl mx-auto space-y-6 text-center">
                <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center mx-auto shadow-sm">
                  <User className="w-7 h-7" />
                </div>

                <div className="space-y-1">
                  <h3 className="font-display text-2xl font-bold text-neutral-900">
                    Step 1: Identify as Registered Voter
                  </h3>
                  <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                    Authenticate your identity to open your personalized biometric and OTP verification session.
                  </p>
                </div>

                {currentVoter ? (
                  /* If already logged in */
                  <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-between gap-4 text-left">
                    <div className="flex items-center gap-3">
                      <img
                        src={currentVoter.facePhotoUrl || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400"}
                        alt={currentVoter.name}
                        className="w-12 h-12 rounded-xl object-cover border border-emerald-500/40"
                      />
                      <div>
                        <div className="text-sm font-bold text-neutral-900">{currentVoter.name}</div>
                        <div className="text-xs text-neutral-500 font-mono">ID: {currentVoter.id} • {currentVoter.constituency}</div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setCurrentStep('FACE_SCAN')}
                      className="py-2.5 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-md flex items-center gap-1.5 cursor-pointer"
                    >
                      Continue
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  /* If not logged in */
                  <div className="space-y-4">
                    <div className="flex flex-col sm:flex-row gap-3">
                      <button
                        type="button"
                        onClick={() => onOpenAuthModal('LOGIN')}
                        className="flex-1 py-3.5 px-5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs sm:text-sm tracking-wide shadow-md flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <User className="w-4 h-4" />
                        Log in with Voter ID
                      </button>

                      <button
                        type="button"
                        onClick={() => onOpenAuthModal('REGISTER')}
                        className="flex-1 py-3.5 px-5 rounded-xl border border-neutral-300 hover:bg-neutral-50 text-neutral-800 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer"
                      >
                        Register New Voter
                      </button>
                    </div>

                    {/* Quick Demo Credentials Preview */}
                    <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200/80 text-left space-y-2">
                      <div className="flex items-center justify-between text-[11px] font-bold text-neutral-500 uppercase tracking-wider">
                        <span>Pre-Registered Demo Credentials:</span>
                        <span className="text-emerald-700 font-mono">VOT-2026-0341</span>
                      </div>
                      <p className="text-xs text-neutral-600">
                        Default Demo ID: <strong>VOT-2026-0341</strong> &bull; Password: <strong>Vote@123</strong> (Asha Verma). You can also click Register to test with your own photo and details!
                      </p>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* STEP 2: FACE VERIFICATION */}
            {currentStep === 'FACE_SCAN' && currentVoter && (
              <FaceVerification
                voter={currentVoter}
                onVerified={handleFaceVerified}
                onCancel={() => setCurrentStep('LOGIN')}
              />
            )}

            {/* STEP 3: OTP VERIFICATION */}
            {currentStep === 'OTP' && currentVoter && (
              <OtpVerification
                voter={currentVoter}
                onVerified={handleOtpVerified}
                onBack={() => setCurrentStep('FACE_SCAN')}
              />
            )}

            {/* STEP 4: SECRET BALLOT */}
            {currentStep === 'BALLOT' && currentVoter && (
              <BallotChamber
                election={election}
                voter={currentVoter}
                onCastVote={handleVoteCast}
                onCancel={() => setCurrentStep('LOGIN')}
              />
            )}

            {/* STEP 5: VOTE RECEIPT */}
            {currentStep === 'RECEIPT' && activeReceipt && (
              <VotingReceipt
                receipt={activeReceipt}
                onViewResults={onNavigateToResults}
                onRestart={() => setCurrentStep('LOGIN')}
              />
            )}
          </div>
        )}
      </div>
    </section>
  );
};
