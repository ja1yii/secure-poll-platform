import React from 'react';
import { X, ShieldCheck, QrCode, Printer, CheckCircle2, User } from 'lucide-react';
import { Voter } from '../types';

interface VoterIdCardModalProps {
  voter: Voter | null;
  isOpen: boolean;
  onClose: () => void;
  onStartVoting?: () => void;
}

export const VoterIdCardModal: React.FC<VoterIdCardModalProps> = ({
  voter,
  isOpen,
  onClose,
  onStartVoting
}) => {
  if (!isOpen || !voter) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-neutral-200 overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="bg-emerald-950 text-white px-6 py-4 flex items-center justify-between border-b border-emerald-900/40">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h3 className="font-display text-lg font-bold">National Digital Voter Identity Card</h3>
          </div>
          <button onClick={onClose} className="text-neutral-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Card Mockup */}
          <div className="rounded-2xl bg-gradient-to-br from-emerald-900 via-emerald-950 to-neutral-950 text-white p-6 shadow-xl border border-emerald-700/60 relative overflow-hidden">
            {/* Hologram sheen pattern */}
            <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:12px_12px]"></div>
            <div className="absolute -right-12 -bottom-12 w-48 h-48 rounded-full bg-emerald-500/10 blur-2xl pointer-events-none"></div>

            {/* Header */}
            <div className="flex items-center justify-between border-b border-emerald-800/80 pb-3 mb-4 relative z-10">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-emerald-600 flex items-center justify-center font-bold text-white text-xs shadow-md">
                  ✓
                </div>
                <div>
                  <div className="text-[10px] tracking-widest uppercase font-mono text-emerald-400">DEMOCRATIC ELECTORAL ROLL</div>
                  <div className="font-display font-bold text-sm text-white">DIGITAL VOTER IDENTITY</div>
                </div>
              </div>
              <span className="text-[10px] font-mono bg-emerald-900/80 border border-emerald-700/80 px-2 py-0.5 rounded text-emerald-300">
                OFFICIAL
              </span>
            </div>

            {/* Body */}
            <div className="flex gap-4 items-start relative z-10">
              {/* Photo */}
              <div className="relative shrink-0">
                <img
                  src={voter.facePhotoUrl || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400"}
                  alt={voter.name}
                  className="w-20 h-24 rounded-xl object-cover border-2 border-emerald-500/80 shadow-md"
                />
                <div className="absolute -bottom-1.5 -right-1.5 bg-emerald-600 text-white rounded-full p-0.5 text-[10px]">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                </div>
              </div>

              {/* Data fields */}
              <div className="space-y-1.5 flex-1 min-w-0 text-xs">
                <div>
                  <span className="text-[10px] text-emerald-400/80 block uppercase tracking-wider">Legal Name</span>
                  <div className="font-bold text-base text-white truncate">{voter.name}</div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <span className="text-[10px] text-emerald-400/80 block uppercase tracking-wider">Voter ID</span>
                    <div className="font-mono font-bold text-emerald-300">{voter.id}</div>
                  </div>
                  <div>
                    <span className="text-[10px] text-emerald-400/80 block uppercase tracking-wider">Constituency</span>
                    <div className="font-semibold text-white truncate">{voter.constituency}</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <span className="text-[10px] text-emerald-400/80 block uppercase tracking-wider">DOB</span>
                    <div className="font-mono text-neutral-300">{voter.dob}</div>
                  </div>
                  <div>
                    <span className="text-[10px] text-emerald-400/80 block uppercase tracking-wider">Status</span>
                    <span className={`inline-block font-bold text-[10px] px-2 py-0.5 rounded ${
                      voter.hasVoted
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    }`}>
                      {voter.hasVoted ? 'BALLOT CAST' : 'ELIGIBLE TO VOTE'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom bar & simulated barcode */}
            <div className="mt-4 pt-3 border-t border-emerald-800/80 flex items-center justify-between text-[10px] font-mono text-emerald-400/90 relative z-10">
              <span>SECURITY: BIOMETRIC + OTP ENABLED</span>
              <span className="tracking-widest">||| | |||| | ||| || ||||</span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-3">
            {onStartVoting && !voter.hasVoted && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onStartVoting();
                }}
                className="flex-1 py-3 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
              >
                Proceed to Voting Chamber
              </button>
            )}
            <button
              type="button"
              onClick={() => window.print()}
              className="py-3 px-4 rounded-xl border border-neutral-300 text-neutral-700 text-xs font-semibold hover:bg-neutral-50 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              Print Voter ID
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
