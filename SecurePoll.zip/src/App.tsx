/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { HowItWorks } from './components/HowItWorks';
import { VotingChamber } from './components/VotingChamber';
import { ElectionResults } from './components/ElectionResults';
import { AuditLedger } from './components/AuditLedger';
import { Footer } from './components/Footer';
import { VoterAuthModal } from './components/VoterAuthModal';
import { VoterIdCardModal } from './components/VoterIdCardModal';
import { Voter } from './types';
import {
  getCurrentVoter,
  setCurrentVoter,
  getVoteResults,
  getAuditLogs,
  resetDemoState,
  INITIAL_ELECTION
} from './services/storage';

export default function App() {
  const [activeTab, setActiveTab] = useState<'HOME' | 'VOTE' | 'RESULTS' | 'AUDIT'>('HOME');
  const [currentVoter, setVoter] = useState<Voter | null>(null);
  const [results, setResults] = useState<Record<string, number>>({});
  const [auditLogs, setAuditLogs] = useState(getAuditLogs());

  // Modals state
  const [authModalOpen, setAuthModalOpen] = useState<boolean>(false);
  const [authModalTab, setAuthModalTab] = useState<'LOGIN' | 'REGISTER'>('LOGIN');
  const [voterCardOpen, setVoterCardOpen] = useState<boolean>(false);
  const [resetToast, setResetToast] = useState<boolean>(false);

  // Load initial state
  useEffect(() => {
    const voter = getCurrentVoter();
    setVoter(voter);
    setResults(getVoteResults());
    setAuditLogs(getAuditLogs());
  }, []);

  // Update tallies after vote
  const refreshElectionData = () => {
    setResults(getVoteResults());
    setAuditLogs(getAuditLogs());
    setVoter(getCurrentVoter());
  };

  const handleOpenAuth = (tab: 'LOGIN' | 'REGISTER') => {
    setAuthModalTab(tab);
    setAuthModalOpen(true);
  };

  const handleAuthSuccess = (voter: Voter) => {
    setVoter(voter);
    refreshElectionData();
    // After login or registration, open digital voter ID card or start voting
    setVoterCardOpen(true);
  };

  const handleLogout = () => {
    setCurrentVoter(null);
    setVoter(null);
    setActiveTab('HOME');
  };

  const handleResetDemo = () => {
    resetDemoState();
    setVoter(null);
    setResults(getVoteResults());
    setAuditLogs(getAuditLogs());
    setActiveTab('HOME');
    setResetToast(true);
    setTimeout(() => setResetToast(false), 3000);
  };

  const handleStartVoting = () => {
    setActiveTab('VOTE');
    setTimeout(() => {
      const el = document.getElementById('demo');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  return (
    <div className="min-h-screen flex flex-col bg-neutral-50 text-neutral-900 selection:bg-emerald-200 selection:text-emerald-950">
      {/* Toast for Demo Reset */}
      {resetToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-neutral-900 text-white text-xs font-semibold px-4 py-3 rounded-2xl shadow-2xl border border-neutral-700 animate-in slide-in-from-bottom-5">
          Electoral demo state has been reset to defaults.
        </div>
      )}

      {/* Main Navbar */}
      <Navbar
        currentVoter={currentVoter}
        activeTab={activeTab}
        onNavigate={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenLogin={() => handleOpenAuth('LOGIN')}
        onOpenRegister={() => handleOpenAuth('REGISTER')}
        onOpenVoterCard={() => setVoterCardOpen(true)}
        onLogout={handleLogout}
        onResetDemo={handleResetDemo}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* VIEW: HOME (Overview, Hero, Live Demo Chamber, How it works) */}
        {activeTab === 'HOME' && (
          <>
            <Hero
              currentVoter={currentVoter}
              onStartVoting={handleStartVoting}
              onOpenRegister={() => handleOpenAuth('REGISTER')}
              onOpenHowItWorks={() => {
                const el = document.getElementById('how-it-works');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
            />

            <HowItWorks />

            {/* Inlined Demo Voting Chamber */}
            <VotingChamber
              election={INITIAL_ELECTION}
              currentVoter={currentVoter}
              onOpenAuthModal={handleOpenAuth}
              onOpenVoterCard={() => setVoterCardOpen(true)}
              onVoteCompleted={refreshElectionData}
              onNavigateToResults={() => {
                setActiveTab('RESULTS');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />

            {/* Quick Live Results Preview Section */}
            <section className="py-16 bg-white border-t border-neutral-200/80">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
                  <h3 className="font-display text-3xl font-bold text-neutral-900">
                    Live Election Monitor
                  </h3>
                  <p className="text-xs sm:text-sm text-neutral-600">
                    Real-time ballot counts update instantly as verified citizens cast their vote.
                  </p>
                </div>

                <ElectionResults
                  election={INITIAL_ELECTION}
                  results={results}
                  onVoteClick={handleStartVoting}
                />
              </div>
            </section>
          </>
        )}

        {/* VIEW: STANDALONE VOTING CHAMBER */}
        {activeTab === 'VOTE' && (
          <div className="py-10">
            <VotingChamber
              election={INITIAL_ELECTION}
              currentVoter={currentVoter}
              onOpenAuthModal={handleOpenAuth}
              onOpenVoterCard={() => setVoterCardOpen(true)}
              onVoteCompleted={refreshElectionData}
              onNavigateToResults={() => {
                setActiveTab('RESULTS');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />
          </div>
        )}

        {/* VIEW: LIVE RESULTS */}
        {activeTab === 'RESULTS' && (
          <div className="py-12 sm:py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8">
            <ElectionResults
              election={INITIAL_ELECTION}
              results={results}
              onVoteClick={handleStartVoting}
            />
          </div>
        )}

        {/* VIEW: AUDIT LEDGER */}
        {activeTab === 'AUDIT' && (
          <div className="py-12 sm:py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8">
            <AuditLedger auditLogs={auditLogs} />
          </div>
        )}
      </main>

      {/* Global Footer */}
      <Footer />

      {/* Login & Registration Modal */}
      <VoterAuthModal
        isOpen={authModalOpen}
        initialTab={authModalTab}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={handleAuthSuccess}
      />

      {/* Digital Voter Card Modal */}
      <VoterIdCardModal
        voter={currentVoter}
        isOpen={voterCardOpen}
        onClose={() => setVoterCardOpen(false)}
        onStartVoting={handleStartVoting}
      />
    </div>
  );
}
