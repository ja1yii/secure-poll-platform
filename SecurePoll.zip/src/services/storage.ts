import { Voter, Candidate, Election, VoteReceipt, AuditRecord } from '../types';

export const INITIAL_CANDIDATES: Candidate[] = [
  {
    id: 'c1',
    name: 'Meera Kulkarni',
    party: 'Unity Party',
    partyColor: '#176b4d',
    symbol: '🏛️',
    photoUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80',
    bio: 'Former Municipal Commissioner and Public Policy Fellow with 14 years in civic reform and clean energy infrastructure.',
    manifesto: [
      'Universal digital governance & open municipal budgets',
      'Clean transit grid expansion & green municipal power',
      'Youth technical apprenticeships and digital literacy'
    ]
  },
  {
    id: 'c2',
    name: 'Rohan Deshpande',
    party: 'Progress Alliance',
    partyColor: '#1d4ed8',
    symbol: '⚡',
    photoUrl: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&auto=format&fit=crop&q=80',
    bio: 'Technology entrepreneur and civic infrastructure advocate focusing on smart public transit and healthcare decentralization.',
    manifesto: [
      'Modernize primary health centers with 24/7 telemedicine',
      'Tax incentives for local technology manufacturing',
      'High-speed fiber connectivity to every municipal ward'
    ]
  },
  {
    id: 'c3',
    name: 'Ananya Patil',
    party: "People's Front",
    partyColor: '#b45309',
    symbol: '🌾',
    photoUrl: 'https://images.unsplash.com/photo-1580894732444-8ecded7900cd?w=400&auto=format&fit=crop&q=80',
    bio: 'Grassroots community organizer and labor rights attorney championing affordable housing and environmental justice.',
    manifesto: [
      'Guaranteed civic community housing & rent stabilization',
      'Farmers and local vendor microcredit fund',
      'Subsidized public education and nutritional support'
    ]
  },
  {
    id: 'c4',
    name: 'Vikram Joshi',
    party: 'Civic Reform Party',
    partyColor: '#7c3aed',
    symbol: '⚖️',
    photoUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&auto=format&fit=crop&q=80',
    bio: 'Senior constitutional lawyer and governance auditor dedicated to electoral transparency and judicial efficiency.',
    manifesto: [
      'Electoral campaign finance disclosure mandates',
      'Independent judicial ombudsman for civic complaints',
      'Zero-waste city mandate and decentralized water recycling'
    ]
  },
  {
    id: 'nota',
    name: 'None of the Above (NOTA)',
    party: 'Neutral Ballot Option',
    partyColor: '#64748b',
    symbol: '🚫',
    photoUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=400&auto=format&fit=crop&q=80',
    bio: 'Official electoral option to record a vote of non-preference among presented candidates.',
    manifesto: [
      'Records democratic dissent against all candidates',
      'Included in constitutional voter turnout statistics',
      'Triggers mandatory review if plurality is achieved'
    ]
  }
];

export const INITIAL_ELECTION: Election = {
  id: 'elec-2026-general',
  title: '2026 General Civic & Legislative Election',
  category: 'Metropolitan General Election',
  description: 'Official democratic ballot for electing the civic parliamentary representative of District 04.',
  status: 'ACTIVE',
  endsAt: '2026-11-15T18:00:00Z',
  totalRegisteredVoters: 24500,
  candidates: INITIAL_CANDIDATES
};

export const INITIAL_VOTERS: Voter[] = [
  {
    id: 'VOT-2026-0341',
    name: 'Asha Verma',
    email: 'asha.verma@civicmail.org',
    phone: '+91 98765 44821',
    password: 'Vote@123',
    dob: '1992-06-14',
    constituency: 'Central District 04',
    registeredAt: '2024-02-10T10:30:00Z',
    facePhotoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    hasVoted: false,
    votedElectionIds: [],
    voterCardIssued: true
  },
  {
    id: 'VOT-2026-0892',
    name: 'Rajesh Khurana',
    email: 'rajesh.k@securemail.in',
    phone: '+91 98210 88319',
    password: 'Vote@123',
    dob: '1987-11-23',
    constituency: 'Central District 04',
    registeredAt: '2024-03-01T14:15:00Z',
    facePhotoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80',
    hasVoted: false,
    votedElectionIds: [],
    voterCardIssued: true
  }
];

const INITIAL_RESULTS: Record<string, number> = {
  c1: 128,
  c2: 96,
  c3: 74,
  c4: 52,
  nota: 11
};

const STORAGE_KEYS = {
  VOTERS: 'securepoll_voters_v2',
  CURRENT_VOTER: 'securepoll_current_voter_v2',
  VOTES: 'securepoll_votes_tally_v2',
  RECEIPTS: 'securepoll_receipts_v2',
  AUDIT_LOGS: 'securepoll_audit_logs_v2'
};

// Simple cryptographic hash simulator for client receipts
export function generateBallotHash(voterId: string, candidateId: string, timestamp: string): string {
  const payload = `${voterId}::${candidateId}::${timestamp}::SECURE_SALT_9901`;
  let hash = 0;
  for (let i = 0; i < payload.length; i++) {
    const char = payload.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0;
  }
  const hex = Math.abs(hash).toString(16).padStart(8, '0');
  const randBlock = Math.random().toString(36).substring(2, 10).toUpperCase();
  const timeBlock = Date.now().toString(36).toUpperCase();
  return `0x${hex}${randBlock}${timeBlock}`.toUpperCase();
}

export function getStoredVoters(): Voter[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.VOTERS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.VOTERS, JSON.stringify(INITIAL_VOTERS));
      return INITIAL_VOTERS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_VOTERS;
  }
}

export function saveStoredVoters(voters: Voter[]) {
  localStorage.setItem(STORAGE_KEYS.VOTERS, JSON.stringify(voters));
}

export function getCurrentVoter(): Voter | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CURRENT_VOTER);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function setCurrentVoter(voter: Voter | null) {
  if (voter) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_VOTER, JSON.stringify(voter));
  } else {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_VOTER);
  }
}

export function getVoteResults(): Record<string, number> {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.VOTES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.VOTES, JSON.stringify(INITIAL_RESULTS));
      return INITIAL_RESULTS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_RESULTS;
  }
}

export function getStoredReceipts(): VoteReceipt[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.RECEIPTS);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function getAuditLogs(): AuditRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
    if (!raw) {
      const initialLogs: AuditRecord[] = [
        {
          id: 'aud-001',
          receiptId: 'REC-2026-9481',
          ballotHashMasked: '0x7E3A••••••••B419',
          electionTitle: INITIAL_ELECTION.title,
          timestamp: new Date(Date.now() - 3600000 * 4).toLocaleString(),
          verificationBadge: 'Face Biometric + SMS 2FA',
          status: 'VERIFIED'
        },
        {
          id: 'aud-002',
          receiptId: 'REC-2026-9482',
          ballotHashMasked: '0x99A1••••••••C702',
          electionTitle: INITIAL_ELECTION.title,
          timestamp: new Date(Date.now() - 3600000 * 3).toLocaleString(),
          verificationBadge: 'Face Biometric + SMS 2FA',
          status: 'VERIFIED'
        },
        {
          id: 'aud-003',
          receiptId: 'REC-2026-9483',
          ballotHashMasked: '0x43F8••••••••E881',
          electionTitle: INITIAL_ELECTION.title,
          timestamp: new Date(Date.now() - 3600000 * 1.5).toLocaleString(),
          verificationBadge: 'Face Biometric + SMS 2FA',
          status: 'VERIFIED'
        }
      ];
      localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(initialLogs));
      return initialLogs;
    }
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function registerVoter(newVoterData: Omit<Voter, 'hasVoted' | 'votedElectionIds' | 'registeredAt' | 'voterCardIssued'>): { success: boolean; voter?: Voter; error?: string } {
  const voters = getStoredVoters();
  
  // Check if voter ID or email exists
  const existingId = voters.find(v => v.id.toUpperCase() === newVoterData.id.toUpperCase());
  if (existingId) {
    return { success: false, error: `Voter ID "${newVoterData.id}" is already registered.` };
  }

  const existingEmail = voters.find(v => v.email.toLowerCase() === newVoterData.email.toLowerCase());
  if (existingEmail) {
    return { success: false, error: `Email "${newVoterData.email}" is already registered.` };
  }

  const voter: Voter = {
    ...newVoterData,
    registeredAt: new Date().toISOString(),
    hasVoted: false,
    votedElectionIds: [],
    voterCardIssued: true
  };

  voters.push(voter);
  saveStoredVoters(voters);
  setCurrentVoter(voter);
  return { success: true, voter };
}

export function loginVoter(identifier: string, pass: string): { success: boolean; voter?: Voter; error?: string } {
  const voters = getStoredVoters();
  const cleanId = identifier.trim().toUpperCase();
  const cleanEmail = identifier.trim().toLowerCase();

  const voter = voters.find(v => 
    (v.id.toUpperCase() === cleanId || v.email.toLowerCase() === cleanEmail)
  );

  if (!voter) {
    return { success: false, error: 'No registered voter found with this Voter ID or Email.' };
  }

  if (voter.password !== pass) {
    return { success: false, error: 'Incorrect password entered. Please try again.' };
  }

  setCurrentVoter(voter);
  return { success: true, voter };
}

export function castBallotRecord(params: {
  electionId: string;
  candidateId: string;
  voter: Voter;
  faceConfidenceScore: number;
}): { success: boolean; receipt?: VoteReceipt; error?: string } {
  const voters = getStoredVoters();
  const voterIndex = voters.findIndex(v => v.id === params.voter.id);

  if (voterIndex === -1) {
    return { success: false, error: 'Voter record not found in electoral roll.' };
  }

  const storedVoter = voters[voterIndex];
  const votedElections = storedVoter.votedElectionIds || [];

  if (votedElections.includes(params.electionId) || storedVoter.hasVoted) {
    return { success: false, error: 'Multiple voting prohibited. You have already cast your official vote in this election.' };
  }

  // Find candidate
  const candidate = INITIAL_CANDIDATES.find(c => c.id === params.candidateId);
  if (!candidate) {
    return { success: false, error: 'Selected candidate is invalid.' };
  }

  // Increment tally
  const results = getVoteResults();
  results[params.candidateId] = (results[params.candidateId] || 0) + 1;
  localStorage.setItem(STORAGE_KEYS.VOTES, JSON.stringify(results));

  // Update voter
  votedElections.push(params.electionId);
  storedVoter.hasVoted = true;
  storedVoter.votedElectionIds = votedElections;
  voters[voterIndex] = storedVoter;
  saveStoredVoters(voters);
  setCurrentVoter(storedVoter);

  // Generate Receipt
  const timestamp = new Date().toISOString();
  const receiptId = `REC-2026-${Math.floor(1000 + Math.random() * 9000)}`;
  const ballotHash = generateBallotHash(storedVoter.id, candidate.id, timestamp);
  const digitalSignature = `SIG::SHA256::${ballotHash.slice(2, 18)}::SECUREPOLL-GOV`;

  const receipt: VoteReceipt = {
    receiptId,
    ballotHash,
    electionId: params.electionId,
    electionTitle: INITIAL_ELECTION.title,
    voterId: storedVoter.id,
    voterName: storedVoter.name,
    candidateId: candidate.id,
    candidateName: candidate.name,
    partyName: candidate.party,
    timestamp: new Date().toLocaleString(),
    verificationMethods: {
      faceVerified: true,
      otpVerified: true,
      faceConfidenceScore: params.faceConfidenceScore
    },
    digitalSignature
  };

  // Save receipt
  const receipts = getStoredReceipts();
  receipts.unshift(receipt);
  localStorage.setItem(STORAGE_KEYS.RECEIPTS, JSON.stringify(receipts));

  // Add audit record
  const auditLogs = getAuditLogs();
  const maskedHash = `${ballotHash.slice(0, 6)}••••••••${ballotHash.slice(-4)}`;
  auditLogs.unshift({
    id: `aud-${Date.now()}`,
    receiptId,
    ballotHashMasked: maskedHash,
    electionTitle: INITIAL_ELECTION.title,
    timestamp: receipt.timestamp,
    verificationBadge: `Face Biometric (${params.faceConfidenceScore}%) + SMS 2FA`,
    status: 'VERIFIED'
  });
  localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(auditLogs));

  return { success: true, receipt };
}

export function resetDemoState() {
  localStorage.setItem(STORAGE_KEYS.VOTERS, JSON.stringify(INITIAL_VOTERS));
  localStorage.setItem(STORAGE_KEYS.VOTES, JSON.stringify(INITIAL_RESULTS));
  localStorage.removeItem(STORAGE_KEYS.RECEIPTS);
  localStorage.removeItem(STORAGE_KEYS.CURRENT_VOTER);
  localStorage.removeItem(STORAGE_KEYS.AUDIT_LOGS);
}
