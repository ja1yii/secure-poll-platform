export interface Voter {
  id: string; // e.g., "VOT-2026-0341"
  name: string;
  email: string;
  phone: string;
  password: string;
  dob: string;
  constituency: string;
  registeredAt: string;
  facePhotoUrl?: string; // Data URL or avatar URL for biometric matching
  hasVoted?: boolean;
  votedElectionIds?: string[];
  voterCardIssued: boolean;
}

export interface Candidate {
  id: string;
  name: string;
  party: string;
  partyColor: string;
  symbol: string;
  photoUrl: string;
  manifesto: string[];
  bio: string;
}

export interface Election {
  id: string;
  title: string;
  category: string;
  description: string;
  status: 'ACTIVE' | 'UPCOMING' | 'CONCLUDED';
  endsAt: string;
  totalRegisteredVoters: number;
  candidates: Candidate[];
}

export interface VoteReceipt {
  receiptId: string;
  ballotHash: string;
  electionId: string;
  electionTitle: string;
  voterId: string;
  voterName: string;
  candidateId: string;
  candidateName: string;
  partyName: string;
  timestamp: string;
  verificationMethods: {
    faceVerified: boolean;
    otpVerified: boolean;
    faceConfidenceScore: number;
  };
  digitalSignature: string;
}

export interface AuditRecord {
  id: string;
  receiptId: string;
  ballotHashMasked: string;
  electionTitle: string;
  timestamp: string;
  verificationBadge: string;
  status: 'VERIFIED' | 'TAMPER_PROOF';
}

export type VotingStep = 'LOGIN' | 'FACE_SCAN' | 'OTP' | 'BALLOT' | 'RECEIPT';
