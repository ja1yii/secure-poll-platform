# SecurePoll — Biometric & OTP E-Voting System

An enterprise-grade online voting platform featuring biometric face verification, instant SMS OTP validation, cryptographic ballot receipts, and live election tallying.

---

## How to Run in Visual Studio Code (VS Code)

If you are running this project locally on your machine in VS Code, follow these quick steps:

### 1. Requirements
- **Node.js**: Make sure you have **Node.js (v18.0.0 or higher, ideally v20+)** installed.
  - Check in terminal:
    ```bash
    node -v
    npm -v
    ```
  - If not installed, download from [nodejs.org](https://nodejs.org/).

---

### 2. Install Dependencies (Crucial First Step)
Before running the project for the first time, you must install the npm packages:
```bash
npm install
```
*(If dependencies are not installed, VS Code will throw `'vite' is not recognized as an internal or external command` or `Cannot find module`).*

---

### 3. Start the Development Server
Run either of these commands in the VS Code terminal (`Terminal` -> `New Terminal` or `Ctrl + ~`):

```bash
npm run dev
```
*or*
```bash
npm start
```

Once started, open your browser and navigate to:
```
http://localhost:3000
```

---

### 4. Common VS Code Run Errors & Quick Fixes

#### Error: `'vite' is not recognized as an internal or external command`
- **Cause**: Dependencies were not installed yet.
- **Fix**: Run `npm install` in your project folder, then run `npm run dev`.

#### Error: `File npm.ps1 cannot be loaded because running scripts is disabled on this system` (Windows PowerShell)
- **Cause**: Windows PowerShell execution policy restricts script execution.
- **Fix**: Either:
  1. Switch your VS Code terminal from **PowerShell** to **Command Prompt (cmd)** or **Git Bash** (click the `+` dropdown in the terminal panel), **OR**
  2. Open PowerShell as Administrator and run:
     ```powershell
     Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
     ```

#### Error: `Port 3000 is in use`
- **Cause**: Another app or previous server instance is already running on port 3000.
- **Fix**: Run on a different port:
  ```bash
  npx vite --port 5173
  ```

#### Error: `Cannot find module '@tailwindcss/vite'` or build errors
- **Fix**: Delete `node_modules` and reinstall:
  ```bash
  rm -rf node_modules package-lock.json
  npm install
  npm run dev
  ```
  *(On Windows PowerShell, use `Remove-Item -Recurse -Force node_modules`)*

---

## Default Demo Voter Credentials

For quick testing without creating a new account:
- **Voter ID**: `VOT-2026-0341`
- **Password**: `Vote@123`
*(Voter: Asha Verma — Central District 04)*

You can also click **"Register"** in the top navigation to create a new voter identity with your own details and webcam biometric profile.
